export class MirPrsnQstn {
  public prsnId = 0;
  public qstnCdId = 0;
  public qstnAswrTxt = '';
  //not in db
  public qstnTxt? = '';  
}

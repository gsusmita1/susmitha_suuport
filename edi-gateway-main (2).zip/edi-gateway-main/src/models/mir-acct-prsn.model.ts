export class MirAcctPrsn {
  public aplctnName : string = '';
  public acctPrsnId : number = 0;
	public prsnId : number = 0;
	public acctId : number = 0;
	public roleId : number = 0;
	public recAddTs : Date = new Date();
	public recAddUserName : string = '';
  public recUpdtTs : Date = new Date();
  public recUpdtUserName : string = '';
}

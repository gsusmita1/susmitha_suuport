
export class EdiMessage {
    application: string = '';
    message: string = '';
  }
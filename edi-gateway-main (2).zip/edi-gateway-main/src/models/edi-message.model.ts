
export class EdiMessage extends Object{
    application: string = '';
    message: string = '';
  }
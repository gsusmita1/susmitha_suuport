export class CobAddress {
    public line1: string | null = null;
    public line2: string | null = null;
    public line3: string | null = null;
    public line4: string | null = null;
    public city: string | null = null;
    public state: string | null = null;
    public zipcode: string | null = null;
    
}
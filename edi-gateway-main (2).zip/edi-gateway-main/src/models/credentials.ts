export class Credentials {
    public username: string = "";
    public password: string = "";
}
export class CobName {
    public first: string = '';
    public middle: string = '';
    public  last: string = '';
}
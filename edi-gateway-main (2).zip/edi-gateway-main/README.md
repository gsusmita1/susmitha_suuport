# edi-gateway

  Possible DEPLOY_ENV settings  
  - mock - used to bypass DL and return mock data instead.
  - local - Uses the DL running on localhost
  - dev - Uses the DL running in dev environment  
  
  Default port is 8080. Set DEPLOY_PORT value to change to other port.
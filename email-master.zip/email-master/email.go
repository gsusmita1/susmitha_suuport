package main

import (
	"bytes"
	"fmt"
	"html/template"
	"encoding/base64"
	"io/ioutil"
	"net/smtp"
	"context"
	"log"
	"strings"
	"os"
	"errors"
	"github.com/aws/aws-lambda-go/lambda"
    	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
    	"github.com/aws/aws-sdk-go/service/dynamodb"
	"github.com/aws/aws-sdk-go/service/dynamodb/dynamodbattribute"
)



func HandleRequest(ctx context.Context, request Item) (string, error) {

	fmt.Println("Found item:")
	fmt.Println("Category:  ", request.Category)
	fmt.Println("Key: ", request.Key)
	fmt.Println("Bcc:  ", request.Bcc)
	fmt.Println("Cc:", request.Cc)
	fmt.Println("From:", request.From)
	fmt.Println("To:", request.To)
	fmt.Println("Subject:", request.Subject)
	fmt.Println("ReporterID:", request.ReporterID)

	category := request.Category
	key := request.Key


	data := GetData(category, key )
	vpc := os.Getenv("vpc")

	appLink :="https://cob.cms.hhs.gov/"
	if vpc == "pro" {
		appLink = "https://cob.cms.hhs.gov/"
	}else if vpc == "imp"{
		appLink = "https://imp.cob.cms.hhs.gov/"
	}else {
		appLink = "https://dev.cob.cms.hhs.gov/"
	}
	
	templateData := struct {
		First string
		Last  string
		ReporterID string
		AppLink string
		Pin string
		Password string
		AmFirst string
		AmLast string
		Token string
		RreId string
		RreName string
		Pending bool
		Login string
		DesigneeFirst string
		DesigneeLast string
		Email string
		Message string
		DataFields []string
	}{
		First: request.First,
		Last:  request.Last,
		ReporterID: request.ReporterID,
		AppLink: appLink,
		Pin: request.Pin,
		Password: request.Password,
		AmFirst: request.AmFirst,
		AmLast: request.AmLast,
		Token: request.Token,
		RreId: request.RreId,
		RreName: request.RreName,
		Pending: request.Pending,
		Login: request.Login,
		DesigneeFirst: request.DesigneeFirst,
		DesigneeLast: request.DesigneeLast,
		Email:request.Email,
		Message:request.Message,
		DataFields:request.DataFields,
	}
	subject := data.Subject;
	//added validation
	if len(request.To) > 0 {
		for _, a := range addresses {
        	if addr, ok := validMailAddress(a); ok {
            		fmt.Printf("value: %-30s valid email: %-10t address: %s\n", a, ok, addr)
	    		return "", errors.New("Not a valid email address"+addr")
			}
        	}
    	}
	if len(request.Cc) > 0 {
		for _, a := range addresses {
        	if addr, ok := validMailAddress(a); ok {
            		fmt.Printf("value: %-30s valid email: %-10t address: %s\n", a, ok, addr)
	    		return "", errors.New("Not a valid email address"+addr")
       		 	} 
    		}
       }
	if data.From == "" { 
		fmt.Println("From address is empty")
		return "", errors.New("From address is empty")
	}else{
		if addr, ok := validMailAddress(data.From); ok {
            		fmt.Printf("value: %-30s valid email: %-10t address: %s\n", data.From, ok, addr)
	    		return "", errors.New("Not a valid email address"+addr")
        	}
	}	
	if subject == "" { 
		fmt.Println("Subject is empty")
		return "", errors.New("subject is empty")
	}
	//end validation
	r := NewRequest(data.From, request.To, request.Cc, request.Bcc, subject, request.Filename, request.FileContentBytes, "Hello, World!")
	
	fmt.Println("After initializationl")
	fmt.Println(r.to)
	
	
	if templateData.Message != "" && key == "O001" { 
		fmt.Println(templateData.Message)
		fmt.Println(strings.Split(templateData.Message, ","))
		templateData.DataFields = strings.Split(templateData.Message, ",")
	}

	err := r.ParseTemplate("template/"+data.Template, templateData)
	fmt.Println("after parsing template" )
	
	if err != nil {
		log.Fatal(err)
		return fmt.Sprintln("Email failed"), err
	}
	
	ok, _ := r.BuildMail()
	fmt.Println(ok)
	
  fmt.Println("Email Sent Successfully!")
	
  return fmt.Sprintln("Email Successful"), nil
}

func main(){
	lambda.Start(HandleRequest)
}

//Request struct
type Request struct {
	from    string
	to      []string
	cc		[]string
	bcc 	[]string
	subject string
	body    string
	filename string
	fileContentBytes 	[]byte
}


type Item struct {
    Category   string
    Key  string
    From   string
    To []string
	Bcc []string
	Cc []string
	Subject string 
	First string
	Last string
	ReporterID string
	Name string
	Email string
	Password string
	Login string
	Pin string
	Template string
	AmFirst string
	AmLast string
	Token string
	RreId string
	RreName string
	Pending bool
	DesigneeFirst string
	DesigneeLast string
	Filename string
	Message string
	DataFields []string
	FileContentBytes []byte
}

func NewRequest(from string, to []string, cc []string, bcc []string, subject, filename string, fileContentBytes []byte ,body string,) *Request {
	return &Request{
		from:    from,
		to:      to,
		subject: subject,
		body:    body,
		cc: 	 cc,
		bcc:	 bcc,
		filename: filename,
		fileContentBytes:	fileContentBytes,
	}
}

func validMailAddress(address string) (string, bool) {
    addr, err := mail.ParseAddress(address)
    if err != nil {
        return "", false
    }
    return addr.Address, true
}

func validate(addresses []string)  (error) {
    for _, a := range addresses {
        if addr, ok := validMailAddress(a); ok {
            fmt.Printf("value: %-30s valid email: %-10t address: %s\n", a, ok, addr)
	    return errors.New("Not a valid email address"+addr")
        } else {
            fmt.Printf("value: %-30s valid email: %-10t\n", a, ok)
	    return nil
        }
    }
}

func (r *Request) BuildMail() (bool, error) {

    var buf bytes.Buffer
   
	//r.filename ="template test"

    buf.WriteString(fmt.Sprintf("From: %s\r\n", r.from))
    buf.WriteString(fmt.Sprintf("To: %s\r\n", strings.Join(r.to, ",")))
    buf.WriteString(fmt.Sprintf("Cc: %s\r\n", strings.Join(r.cc, ",")))
	buf.WriteString(fmt.Sprintf("Subject: %s\r\n", r.subject))

    boundary := "my-boundary-779"
    buf.WriteString("MIME-Version: 1.0\r\n")
    buf.WriteString(fmt.Sprintf("Content-Type: multipart/mixed; boundary=%s\n", 
        boundary))

    buf.WriteString(fmt.Sprintf("\r\n--%s\r\n", boundary))
    buf.WriteString("MIME-version: 1.0;\nContent-Type: text/html; charset=\"UTF-8\";\r\n")
    buf.WriteString(fmt.Sprintf("\r\n%s\r\n", r.body))


		//r.fileContentBytes = readFile("template/template.html")
		//fmt.Println(r.fileContentBytes)
	if len(strings.TrimSpace(r.filename)) != 0 && r.fileContentBytes != nil && len(r.fileContentBytes) != 0  {
		buf.WriteString(fmt.Sprintf("\r\n--%s\r\n", boundary))
		buf.WriteString("Content-Type: text/html; charset=\"utf-8\"\r\n")
		buf.WriteString("Content-Transfer-Encoding: base64\r\n")
		buf.WriteString("Content-Disposition: attachment;filename=\"" + r.filename + "\"\r\n")
    	b := make([]byte, base64.StdEncoding.EncodedLen(len(r.fileContentBytes)))
    	base64.StdEncoding.Encode(b, r.fileContentBytes)
    
		fmt.Println(b)
		buf.Write(b)
    	buf.WriteString(fmt.Sprintf("\r\n--%s", boundary))
		buf.WriteString("--")
	}

	addr := "mailrelay.devops.mspsc.local:25"
	fmt.Println("inside SendEmail")

	all := []string{}
	all = append(r.to,r.cc...)	// Can't concatenate more than 2 slice at once
	all = append(all,r.bcc...)	// concatenate all with bcc
	
	fmt.Printf("\n######### After Concatenation #########\n")
	fmt.Printf("all: %v\n", all)



	if err := smtp.SendMail(addr, nil, r.from, all, buf.Bytes()); err != nil {
		return false, err
	}
	return true, nil
}

func readFile(fileName string) []byte {

    data, err := ioutil.ReadFile(fileName)
    if err != nil {
        log.Fatal(err)
    }

    return data
}

func (r *Request) ParseTemplate(templateFileName string, data interface{}) error {
	t, err := template.ParseFiles(templateFileName)
	if err != nil {
		return err
	}
	buf := new(bytes.Buffer)
	if err = t.Execute(buf, data); err != nil {
		return err
	}
	r.body = buf.String()
	return nil
}


func GetData(category string, key string) Item{
    sess := session.Must(session.NewSessionWithOptions(session.Options{
		SharedConfigState: session.SharedConfigEnable,
	}))

	// Create DynamoDB client
	svc := dynamodb.New(sess)

	
	vpc := os.Getenv("vpc")

    tableName := vpc+"_email"

	out, err := svc.GetItem(&dynamodb.GetItemInput{
		TableName: aws.String(tableName),
		Key: map[string]*dynamodb.AttributeValue{
			"Category": {
				S: aws.String(category),
			},
			"Key": {
				S: aws.String(key),
			},
		},
	})
	
    if err != nil {
        panic(err)
    }

	if out.Item == nil {
		msg := "Could not find data"
		fmt.Println("msg:", msg)
	}
    
	item := Item{}

	err = dynamodbattribute.UnmarshalMap(out.Item, &item)
	if err != nil {
		panic(fmt.Sprintf("Failed to unmarshal Record, %v", err))
	}

	fmt.Println("Found item:")
	fmt.Println("Category:  ", item.Category)
	fmt.Println("Key: ", item.Key)
	fmt.Println("Bcc:  ", item.Bcc)
	fmt.Println("Cc:", item.Cc)
	fmt.Println("From:", item.From)
	fmt.Println("To:", item.To)

	return item
}

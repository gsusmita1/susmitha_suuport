package main

import (
	"bytes"
	"fmt"
	"html/template"
	"net/smtp"
	"context"
	"log"
	"github.com/aws/aws-lambda-go/lambda"
	"github.com/aws/aws-lambda-go/events"
)

func HandleRequest(ctx context.Context, request events.APIGatewayProxyRequest) (string, error) {

	
	templateData := struct {
		Name string
		Message  string
	}{
		Name: "Chhabi",
		Message:  "Template test",
	}
	r := NewRequest([]string{"chhabilata.gudu@gdit.com"}, "Testing template from Lambda", "Hello, World!")
	
	fmt.Println("After initializationl")
	fmt.Println(r.to)

	err := r.ParseTemplate("template.html", templateData)
	fmt.Println("after parsing template" )
	
	if err != nil {
		log.Fatal(err)
		return fmt.Sprintln("Email failed"), err
	}
	
	ok, _ := r.SendEmail()
	fmt.Println(ok)
	
	
	// Second mailrelay
	
	// Sender data.
  from := "lambda2@devops.cob.cms.hhs.gov"
  

  // Receiver email address.
  to := []string{
    "chhabilata.gudu@gdit.com",
  }


  // Message.
  message := []byte("This is a test email message.")
  
  
  // Sending email.
  err2 := smtp.SendMail("mailrelay.devops.mspsc.local:25", nil, from, to, message)
  if err2 != nil {
    fmt.Println(err2)
  }
  fmt.Println("Email Sent Successfully!")
	
  return fmt.Sprintln("Email Successful"), nil
}

func main(){
	lambda.Start(HandleRequest)
}

//Request struct
type Request struct {
	from    string
	to      []string
	subject string
	body    string
}

func NewRequest(to []string, subject, body string) *Request {
	return &Request{
		to:      to,
		subject: subject,
		body:    body,
	}
}


func (r *Request) SendEmail() (bool, error) {

    msg := "MIME-version: 1.0;\nContent-Type: text/html; charset=\"UTF-8\";\r\n"
    msg += fmt.Sprintf("From: %s\r\n", ""lambda@devops.cob.cms.hhs.gov")
    msg += fmt.Sprintf("To: %s\r\n", strings.Join(r.to, ";"))
    msg += fmt.Sprintf("Subject: %s\r\n", "test")
    msg += fmt.Sprintf("\r\n%s\r\n", r.body)

	
	addr := "mailrelay.devops.mspsc.local:25"
	fmt.Println("inside SendEmail")
	fmt.Println(msg)

	if err := smtp.SendMail(addr, nil, "lambda@devops.cob.cms.hhs.gov", r.to, []byte(msg)); err != nil {
		return false, err
	}
	return true, nil
}

func (r *Request) ParseTemplate(templateFileName string, data interface{}) error {
	t, err := template.ParseFiles(templateFileName)
	if err != nil {
		return err
	}
	buf := new(bytes.Buffer)
	if err = t.Execute(buf, data); err != nil {
		return err
	}
	r.body = buf.String()
	return nil
}

package main

import (
	"github.com/aws/aws-lambda-go/lambda"
    "github.com/aws/aws-sdk-go/aws"
    "github.com/aws/aws-sdk-go/aws/session"
    "github.com/aws/aws-sdk-go/service/dynamodb"
    "github.com/aws/aws-sdk-go/service/dynamodb/dynamodbattribute"
	"context"
    "fmt"
    "log"
	"os"
)

type Item struct {
    Category   string
    Key  string
    From   string
    To string
    Bcc string
    Cc string
    Subject string
    Template string
}

func HandleRequest(ctx context.Context, request Item) (string, error) {

	sess := session.Must(session.NewSessionWithOptions(session.Options{
        SharedConfigState: session.SharedConfigEnable,
    }))

    // Create DynamoDB client
    svc := dynamodb.New(sess)

	fmt.Println("Found item:")
	fmt.Println("Category:  ", request.Category)
	fmt.Println("Key: ", request.Key)
	fmt.Println("Bcc:  ", request.Bcc)
	fmt.Println("Cc:", request.Cc)
	fmt.Println("From:", request.From)
	fmt.Println("To:", request.To)
	fmt.Println("Subject:", request.Subject)
	fmt.Println("template:", request.Subject)

    av, err := dynamodbattribute.MarshalMap(request)
    if err != nil {
        log.Fatalf("Got error marshalling new movie item: %s", err)
    }

	vpc := os.Getenv("vpc")

    tableName := vpc+"_email"

    input := &dynamodb.PutItemInput{
        Item:      av,
        TableName: aws.String(tableName),
    }

    _, err = svc.PutItem(input)
    if err != nil {
        log.Fatalf("Got error calling PutItem: %s", err)
    }



    fmt.Println("Successfully added '" + request.Category + "' (" + request.Key + ") to table " + tableName)
	
  return fmt.Sprintln("Successfully addedl"), nil
}

func main(){
	lambda.Start(HandleRequest)
}




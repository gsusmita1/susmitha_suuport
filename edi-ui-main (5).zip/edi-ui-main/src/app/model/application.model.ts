export class Application {

  applicationId: number = 0;
  applicationIdent: number = 0;
  recAddTs: any = undefined;
  recAddUserName: string = '';
  recUpdtTs: any = undefined;
  recUpdtUserName: string = '';
  
}


export class ZipCode {
  zip5: string = '';
  zip4: string = '';
}

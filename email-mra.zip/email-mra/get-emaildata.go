package main

import (
    "github.com/aws/aws-lambda-go/lambda"
    "github.com/aws/aws-sdk-go/aws"
    "github.com/aws/aws-sdk-go/aws/session"
    "github.com/aws/aws-sdk-go/service/dynamodb"
    "github.com/aws/aws-sdk-go/service/dynamodb/dynamodbattribute"
	"context"
	"fmt"
	"os"
)

type Item struct {
    Category   string
    Key  string
    From   string
    To string
	Bcc string
	Cc string
	Subject string 
}


type Response struct {
        Resp string `json:"resp"`
}

type Request struct {
    Category     string `json:"category"`
    Key string `json:"key"`
}

func GetData(category string, key string) Item{
    sess := session.Must(session.NewSessionWithOptions(session.Options{
		SharedConfigState: session.SharedConfigEnable,
	}))

	// Create DynamoDB client
	svc := dynamodb.New(sess)

	
	vpc := os.Getenv("vpc")

    tableName := vpc+"_email"

	out, err := svc.GetItem(&dynamodb.GetItemInput{
		TableName: aws.String(tableName),
		Key: map[string]*dynamodb.AttributeValue{
			"Category": {
				S: aws.String(category),
			},
			"Key": {
				S: aws.String(key),
			},
		},
	})
	
    if err != nil {
        panic(err)
    }

	if out.Item == nil {
		msg := "Could not find data"
		fmt.Println("msg:", msg)
	}
    
	item := Item{}

	err = dynamodbattribute.UnmarshalMap(out.Item, &item)
	if err != nil {
		panic(fmt.Sprintf("Failed to unmarshal Record, %v", err))
	}

	fmt.Println("Found item:")
	fmt.Println("Category:  ", item.Category)
	fmt.Println("Key: ", item.Key)
	fmt.Println("Bcc:  ", item.Bcc)
	fmt.Println("Cc:", item.Cc)
	fmt.Println("From:", item.From)
	fmt.Println("To:", item.To)

	return item
}


func HandleRequest(ctx context.Context, request Request) (Item, error) {
	category :=  request.Category
	fmt.Printf("category received from api: %v\n", category)
	key := request.Key
	fmt.Printf("key received from api: %v\n", key)
	
	data := GetData(category, key )

	return  data,nil
}

func main(){
	lambda.Start(HandleRequest)
}
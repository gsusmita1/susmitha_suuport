package main

import (
	"bytes"
	"fmt"
	"html/template"
	"net/smtp"
	"context"
	"log"
	"strings"
	"os"
	"github.com/aws/aws-lambda-go/lambda"
    "github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
    "github.com/aws/aws-sdk-go/service/dynamodb"
	"github.com/aws/aws-sdk-go/service/dynamodb/dynamodbattribute"
)



func HandleRequest(ctx context.Context, request ApiReq) (string, error) {

	category :=  request.Category
	fmt.Printf("category received from api: %v\n", category)
	key := request.Key
	fmt.Printf("key received from api: %v\n", key)

	data := GetData(category, key )
	
	templateData := struct {
		Name string
		Message  string
	}{
		Name: data.Category,
		Message:  data.Key,
	}
	subject := data.Category + " Response transmission successful from COBC to VDSA " + data.Key
	r := NewRequest(data.From, []string{data.To}, subject, "Hello, World!")
	
	fmt.Println("After initializationl")
	fmt.Println(r.to)

	err := r.ParseTemplate("template2.html", templateData)
	fmt.Println("after parsing template" )
	
	if err != nil {
		log.Fatal(err)
		return fmt.Sprintln("Email failed"), err
	}
	
	ok, _ := r.SendEmail()
	fmt.Println(ok)
	
	
	// Second mailrelay
	
	// Sender data.
  from := data.From
  

  // Receiver email address.
  to := []string{
    data.To,
  }


  // Message.
  message := []byte("This is a test email message.")
  
  
  // Sending email.
  err2 := smtp.SendMail("mailrelay.devops.mspsc.local:25", nil, from, to, message)
  if err2 != nil {
    fmt.Println(err2)
  }
  fmt.Println("Email Sent Successfully!")
	
  return fmt.Sprintln("Email Successful"), nil
}

func main(){
	lambda.Start(HandleRequest)
}

//Request struct
type Request struct {
	from    string
	to      []string
	subject string
	body    string
}


type ApiReq struct {
    Category     string `json:"category"`
    Key string `json:"key"`
}

type Item struct {
    Category   string
    Key  string
    From   string
    To string
	Bcc string
	Cc string
	Subject string 
}

func NewRequest(from string, to []string, subject, body string) *Request {
	return &Request{
		from:    from,
		to:      to,
		subject: subject,
		body:    body,
	}
}


func (r *Request) SendEmail() (bool, error) {

    msg := "MIME-version: 1.0;\nContent-Type: text/html; charset=\"UTF-8\";\r\n"
    msg += fmt.Sprintf("From: %s\r\n", r.from)
    msg += fmt.Sprintf("To: %s\r\n", strings.Join(r.to, ";"))
    msg += fmt.Sprintf("Subject: %s\r\n", r.subject)
    msg += fmt.Sprintf("\r\n%s\r\n", r.body)

	
	addr := "mailrelay.devops.mspsc.local:25"
	fmt.Println("inside SendEmail")
	fmt.Println(msg)

	if err := smtp.SendMail(addr, nil, "lambda@devops.cob.cms.hhs.gov", r.to, []byte(msg)); err != nil {
		return false, err
	}
	return true, nil
}

func (r *Request) ParseTemplate(templateFileName string, data interface{}) error {
	t, err := template.ParseFiles(templateFileName)
	if err != nil {
		return err
	}
	buf := new(bytes.Buffer)
	if err = t.Execute(buf, data); err != nil {
		return err
	}
	r.body = buf.String()
	return nil
}


func GetData(category string, key string) Item{
    sess := session.Must(session.NewSessionWithOptions(session.Options{
		SharedConfigState: session.SharedConfigEnable,
	}))

	// Create DynamoDB client
	svc := dynamodb.New(sess)

	
	vpc := os.Getenv("vpc")

    tableName := vpc+"_email"

	out, err := svc.GetItem(&dynamodb.GetItemInput{
		TableName: aws.String(tableName),
		Key: map[string]*dynamodb.AttributeValue{
			"Category": {
				S: aws.String(category),
			},
			"Key": {
				S: aws.String(key),
			},
		},
	})
	
    if err != nil {
        panic(err)
    }

	if out.Item == nil {
		msg := "Could not find data"
		fmt.Println("msg:", msg)
	}
    
	item := Item{}

	err = dynamodbattribute.UnmarshalMap(out.Item, &item)
	if err != nil {
		panic(fmt.Sprintf("Failed to unmarshal Record, %v", err))
	}

	fmt.Println("Found item:")
	fmt.Println("Category:  ", item.Category)
	fmt.Println("Key: ", item.Key)
	fmt.Println("Bcc:  ", item.Bcc)
	fmt.Println("Cc:", item.Cc)
	fmt.Println("From:", item.From)
	fmt.Println("To:", item.To)

	return item
}
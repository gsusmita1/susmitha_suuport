package main


import (
    "github.com/aws/aws-lambda-go/lambda"
    "github.com/aws/aws-sdk-go/aws"
    "github.com/aws/aws-sdk-go/aws/session"
    "github.com/aws/aws-sdk-go/service/dynamodb"
	"context"
	"fmt"
	"log"
	"os"
)

type Request struct {
    Category     string `json:"category"`
    Key string `json:"key"`
}

func HandleRequest(ctx context.Context, request  Request) (string, error) {
	sess := session.Must(session.NewSessionWithOptions(session.Options{
        SharedConfigState: session.SharedConfigEnable,
    }))

  	category :=  request.Category
	fmt.Printf("category received from api: %v\n", category)
	key := request.Key
	fmt.Printf("key received from api: %v\n", key)
	
	svc := dynamodb.New(sess)

	vpc := os.Getenv("vpc")

    tableName := vpc+"_email"

    input := &dynamodb.DeleteItemInput{
		Key: map[string]*dynamodb.AttributeValue{
			"Category": {
				S: aws.String(category),
			},
			"Key": {
				S: aws.String(key),
			},
		},
        TableName: aws.String(tableName),
    }

    _, err := svc.DeleteItem(input)
    if err != nil {
        log.Fatalf("Got error calling DeleteItem: %s", err)
    }

    fmt.Println("Deleted '" + category + "' (" + category + ") from table " + tableName)
	return fmt.Sprintln("Deleted data successfully "), nil
}

func main(){
	lambda.Start(HandleRequest)
}
/**
 * Copy Matching properties from Source to Target
 * @param target Object of type Any
 * @param source Object of type Any
 */
function copyMatchingKeyValues(target: any, source: any) {
  return Object.keys(target).forEach(key => {
    if (source[key] !== undefined) {
      if (typeof source[key] === 'string' || source[key] instanceof String) {
        target[key] = source[key].trim();
      } else {
        target[key] = source[key];
      }
    }
  });
}

/**
 * Resets all properties of the object that begin with "action" to be false
 * then sets the key property to be true
 * @param target Object with action properties
 * @param key Name of the property to update to true
 */
function setAction( target: any, key: string ) {
  Object.keys(target).forEach(v => {
    if( v.startsWith('action')) { target[v] = false; }
  });
  target[key] = true;
}

export {copyMatchingKeyValues, setAction};

import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  ElementRef,
  ViewChild,
  AfterViewInit,
} from "@angular/core";

@Component({
  selector: "app-vet-submitter",
  templateUrl: "./vet-submitter.component.html",
  styleUrls: ["./vet-submitter.component.css"],
})
export class VetSubmitterComponent implements OnInit, AfterViewInit {
  @ViewChild("container", {}) container: ElementRef;
  @Input() accountInfo;
  @Output() cancel = new EventEmitter();
  @Output() confirm = new EventEmitter();

  constructor() {}

  ngOnInit(): void {}

  ngAfterViewInit() {
    this.container.nativeElement.focus();
  }

  onCancel() {
    this.cancel.emit();
  }

  onConfirm() {
    this.confirm.emit();
  }

  // onHideModel() {
  //   this.display = false;
  //   this.routerService.navigateTo("accountInfo", false);
  // }
}

import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  ElementRef,
  ViewChild,
  AfterViewInit,
} from "@angular/core";

@Component({
  selector: "app-remove-invalid-submitter",
  templateUrl: "./remove-invalid-submitter.component.html",
  styleUrls: ["./remove-invalid-submitter.component.css"],
})
export class RemoveInvalidSubmitterComponent implements OnInit, AfterViewInit {
  @ViewChild("container", {}) container: ElementRef;
  @Input() accountInfo;
  @Output() cancel = new EventEmitter();
  @Output() confirm = new EventEmitter();

  constructor() {}

  ngOnInit(): void {}

  ngAfterViewInit() {
    this.container.nativeElement.focus();
  }

  onCancel() {
    this.cancel.emit();
  }

  onConfirm() {
    this.confirm.emit();
  }
}

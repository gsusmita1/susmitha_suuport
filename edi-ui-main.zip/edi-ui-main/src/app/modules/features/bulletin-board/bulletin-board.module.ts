import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { BulletinBoardComponent } from "./bulletin-board.component";
import { DialogModule } from "primeng/dialog";
import { MultiSelectModule } from "primeng/multiselect";
import { CheckboxModule } from "primeng/checkbox";
import { InputTextareaModule } from "primeng/inputtextarea";
import { FormsModule } from "@angular/forms";
import { BulletinBoardRoutingModule } from "./bulletin-board-routing.module";

@NgModule({
  declarations: [BulletinBoardComponent],
  imports: [
    CommonModule,
    DialogModule,
    FormsModule,
    MultiSelectModule,
    InputTextareaModule,
    BulletinBoardRoutingModule,
    CheckboxModule,
  ],
})
export class BulletinBoardModule {}

import {
  Component,
  OnInit,
  ElementRef,
  ViewChild,
  AfterViewInit,
} from "@angular/core";
import { Router } from "@angular/router";
import { ConfirmationService } from "primeng/api";
import { EcrsService } from "src/app/services/ecrs.service";

@Component({
  selector: "app-ecrs-contractor-lookup",
  templateUrl: "./ecrs-contractor-lookup.component.html",
  styleUrls: ["./ecrs-contractor-lookup.component.css"],
})
export class EcrsContractorLookupComponent implements OnInit, AfterViewInit {
  @ViewChild("container", {}) container: ElementRef;
  contractorId: string = null;
  contractorFound: boolean = false;

  users: any[] = [];

  constructor(
    private router: Router,
    private confirmationService: ConfirmationService,
    private ecrsService: EcrsService
  ) {}

  ngOnInit() {}

  ngAfterViewInit() {
    this.container.nativeElement.focus();
  }

  lookupContractorById() {
    this.ecrsService.getContractorData(this.contractorId).subscribe((res) => {
      this.contractorFound = true;
      this.users = [];
      res.result.userIdList.forEach((element) => {
        this.users.push({ userId: element });
      });
    });
  }

  cancel() {
    this.contractorFound = false;
    this.contractorId = "";
  }
}

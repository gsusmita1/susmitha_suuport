import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  ElementRef,
  ViewChild,
  AfterViewInit,
} from "@angular/core";
import { Router } from "@angular/router";

@Component({
  selector: "app-account-activity",
  templateUrl: "./account-activity.component.html",
  styleUrls: ["./account-activity.component.css"],
})
export class AccountActivityComponent implements OnInit, AfterViewInit {
  @ViewChild("container", {}) container: ElementRef;
  @Input() acctActivity;
  @Output() cancel = new EventEmitter();

  constructor(private router: Router) {}

  ngOnInit() {}
  ngOnChanges() {}
  ngAfterViewInit() {
    //this.container.nativeElement.focus();
  }

  onContinue() {
    this.cancel.emit();
  }
}

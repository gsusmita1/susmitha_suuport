import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ElementRef,
  ViewChild,
  AfterViewInit,
} from "@angular/core";
import { Router } from "@angular/router";
import { ConfirmationService, MenuItem } from "primeng/api";
import { RouterService } from "src/app/services/router.service";
import { takeUntil } from "rxjs/operators";
import { AccountService } from "src/app/services/account.service";
import { Subject } from "rxjs";
import * as moment from "moment";
import { setAction } from "src/app/utils/object.util";

@Component({
  selector: "app-account-info",
  templateUrl: "./account-info.component.html",
  styleUrls: ["./account-info.component.css"],
})
export class AccountInfoComponent implements OnInit, AfterViewInit {
  constructor(
    private routerService: RouterService,
    private router: Router,
    private accountService: AccountService,
    private confirmationService: ConfirmationService
  ) {}
  @Input() accountInfo;
  @Input() appType;
  @Input() fromUserAccess: boolean = false;
  @Input() fromVetSubmitters: boolean = false;
  @Output() closeAccountInfo = new EventEmitter();
  @Output() reinitializeSearch = new EventEmitter();
  @ViewChild("container", {}) container: ElementRef;
  @ViewChild("modal", {}) modal: ElementRef;

  destroy$: Subject<boolean> = new Subject<boolean>();

  submittersData: any;
  accountId: number;
  actions: MenuItem[];
  optInDate: string;
  showModal: boolean = false;
  showResetPinModal: boolean = false;
  modalText: { header: string; body: string };

  showActivity: boolean = false;
  acctActivity: any[] = [];
  showSelected: string = "acctInfo";

  appMap = { WCS: "WCS", MSPRP: "MRP", CRCP: "GHPRP" };

  public selectedOption: String;

  ngOnInit(): void {}

  ngOnChanges() {
    this.buildMenuItems(this.accountInfo.displayInfo);
    this.accountId = this.accountInfo.contactInfo.accountId;
    this.optInDate = this.accountInfo.submitterInfo.paperlessOptInDate
      ? moment(this.accountInfo.submitterInfo.paperlessOptInDate).format(
          "MM/DD/YYYY"
        )
      : "N/A";
  }

  ngAfterViewInit() {
    this.container!.nativeElement.focus();
  }

  ngOnDestroy() {
    this.destroy$.next(true);
    this.destroy$.unsubscribe();
  }

  onCancel() {
    if (this.fromUserAccess) {
      this.routerService.navigateTo("dashboard", true);
    } else if (this.fromVetSubmitters) {
      this.routerService.navigateTo("submittersRequiring", true);
    } else {
      this.closeAccountInfo.emit();
    }
  }

  buildMenuItems(displayInfo) {
    this.actions = [];
    Object.entries(displayInfo).forEach((item) => {
      const [key, value] = item;
      if (value) {
        switch (key) {
          case "optionViewAccountActvity": {
            this.actions.push({
              label: "View Account Activity",
              command: () => {
                this.onAccountActivity();
              },
            });
            break;
          }
          case "optionResendProfileReport": {
            this.actions.push({
              label: "Regenerate/Resend Profile Report",
              command: () => {
                this.onRegenProfile();
              },
            });
            break;
          }
          case "optionRemoveSubmitter": {
            this.actions.push({
              label: "Remove Invalid Submitter/Registrant",
              command: () => {
                this.onRemoveInvalidSubmitter();
              },
            });
            break;
          }
          case "optionVetSubmitter": {
            this.actions.push({
              label: "Vet Submitter/Registrant",
              command: () => {
                this.onVetSubmitter();
              },
            });
            break;
          }
          case "optionGrantFullFunctions": {
            this.actions.push({
              label: "Grant Full WCMSAP/MSPRP/CRCP Functionality",
              command: () => {
                this.onGrantFullFunction();
              },
            });
            break;
          }
          case "optionResetPin": {
            this.actions.push({
              label: "Reset PIN",
              command: () => {
                this.onResetPin();
              },
            });
            break;
          }
          case "optionUnlockPin": {
            this.actions.push({
              label: "Unlock PIN",
              command: () => {
                this.onUnlockPin();
              },
            });
            break;
          }
          case "optionPaperlessEmails": {
            this.actions.push({
              label: "Paperless Emails",
              command: () => {
                this.onPaperlessEmails();
              },
            });
            break;
          }
          case "optionPaperlessParties": {
            this.actions.push({
              label: "Go Paperless Parties",
              command: () => {
                this.onPaperlessParties();
              },
            });
            break;
          }
          default: {
            break;
          }
        }
      }
    });
  }

  onSelectChange(event: any) {}

  onAccountActivity() {
    setAction(this.accountInfo.actionInfo, "actionViewAccountActvity");
    this.accountService
      .sendAccountAction(
        this.accountInfo,
        this.appMap[this.appType] || this.appType
      )
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response) => {
          if (response.result.length) {
            this.acctActivity = response.result;
            this.onShowActivity();
          } else {
            this.modalText = {
              header: "Account Activity Error",
              body: "No activity found for this account",
            };
            this.showModal = true;
            setTimeout(() => this.modal.nativeElement.focus(), 0);
          }
        },
        (err) => {
          this.showError();
        }
      );
  }

  onShowInfo() {
    this.showSelected = "acctInfo";
  }

  onShowActivity() {
    this.showSelected = "acctActivity";
  }

  onRegenProfile() {
    this.confirmationService.confirm({
      message: `Are you sure you want to regenerate/resend the Profile Report for account ${this.accountId}?`,
      accept: () => {
        this.regenProfile();
      },
      reject: () => {},
    });
  }

  onResetPin() {
    this.showSelected = "resetPin";
  }

  onUnlockPin() {
    this.showSelected = "unlockPin";
  }

  onVetSubmitter() {
    this.showSelected = "vetSubmitter";
  }

  onGrantFullFunction() {
    this.showSelected = "grantFunctionality";
  }

  onPaperlessEmails() {
    this.showSelected = "paperlessEmails";
  }

  onPaperlessParties() {
    this.showSelected = "paperlessParties";
  }

  onRemoveInvalidSubmitter() {
    this.showSelected = "removeInvalidSubmitter";
  }

  resetPin(action: string) {
    if (action === "confirm") {
      setAction(this.accountInfo.actionInfo, "actionResetPin");
      this.accountService
        .sendAccountAction(
          this.accountInfo,
          this.appMap[this.appType] || this.appType
        )
        .pipe(takeUntil(this.destroy$))
        .subscribe(
          (response) => {
            this.reinitializeSearch.emit();
            this.onShowInfo();
            this.showResetPinModal = true;
            setTimeout(() => this.modal.nativeElement.focus(), 0);
          },
          (err) => {
            this.showError();
          }
        );
    } else {
      this.onShowInfo();
    }
  }

  regenProfile() {
    setAction(this.accountInfo.actionInfo, "actionResendProfileReport");
    this.accountService
      .sendAccountAction(
        this.accountInfo,
        this.appMap[this.appType] || this.appType
      )
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response) => {
          if (response.status == 200) {
            this.reinitializeSearch.emit();
            this.onShowInfo();
            this.modalText = {
              header: "Regenerate/Resend Profile Report Successful",
              body: `Profile Report regenerated for account #${this.accountId} in the ${this.appType} application.`,
            };
            this.showModal = true;
            setTimeout(() => this.modal.nativeElement.focus(), 0);
          } else {
            this.showError();
          }
        },
        (err) => {
          this.showError();
        }
      );
  }

  unlockPin(action: string) {
    if (action === "confirm") {
      setAction(this.accountInfo.actionInfo, "actionUnlockPin");
      this.accountService
        .sendAccountAction(
          this.accountInfo,
          this.appMap[this.appType] || this.appType
        )
        .pipe(takeUntil(this.destroy$))
        .subscribe(
          (response) => {
            this.reinitializeSearch.emit();
            this.onShowInfo();
            this.modalText = {
              header: "Success",
              body: "PIN Unlocked Successfully",
            };
            this.showModal = true;
            setTimeout(() => this.modal.nativeElement.focus(), 0);
          },
          (err) => {
            this.showError();
          }
        );
    } else {
      this.onShowInfo();
    }
  }

  vetSubmitter(action: string) {
    if (action === "confirm") {
      setAction(this.accountInfo.actionInfo, "actionVetSubmitter");
      this.accountService
        .sendAccountAction(
          this.accountInfo,
          this.appMap[this.appType] || this.appType
        )
        .pipe(takeUntil(this.destroy$))
        .subscribe(
          (response) => {
            this.reinitializeSearch.emit();
            this.onShowInfo();
            this.modalText = {
              header: "Success",
              body: `Submitter/Registrant for Account ${this.accountId} status has been set to Vetted in the WCMSAP/MSPRP/CRCP application.`,
            };
            this.showModal = true;
            setTimeout(() => this.modal.nativeElement.focus(), 0);
          },
          (err) => {
            this.showError();
          }
        );
    } else {
      this.onShowInfo();
    }
  }

  grantFunctionality(action: string) {
    if (action === "confirm") {
      setAction(this.accountInfo.actionInfo, "actionGrantFullFunctions");
      this.accountService
        .sendAccountAction(
          this.accountInfo,
          this.appMap[this.appType] || this.appType
        )
        .pipe(takeUntil(this.destroy$))
        .subscribe(
          (response) => {
            this.reinitializeSearch.emit();
            this.onShowInfo();
            this.modalText = {
              header: "Success",
              body: `Full functionality to the WCMSAP/MSPRP/CRCP application has been granted for
            account ${this.accountId}.`,
            };
            this.showModal = true;
            setTimeout(() => this.modal.nativeElement.focus(), 0);
          },
          (err) => {
            this.showError();
          }
        );
    } else {
      this.onShowInfo();
    }
  }

  removeInvalidSubmitter(action: string) {
    if (action === "confirm") {
      setAction(this.accountInfo.actionInfo, "actionRemoveSubmitter");
      this.accountService
        .sendAccountAction(
          this.accountInfo,
          this.appMap[this.appType] || this.appType
        )
        .pipe(takeUntil(this.destroy$))
        .subscribe(
          (response) => {
            this.reinitializeSearch.emit();
            this.onShowInfo();
            this.modalText = {
              header: "Success",
              body: `Invalid submitter/registrant has been removed.`,
            };
            this.showModal = true;
            setTimeout(() => this.modal.nativeElement.focus(), 0);
          },
          (err) => {
            this.showError();
          }
        );
    } else {
      this.onShowInfo();
    }
  }

  onGo(route: String) {
    this.routerService.navigateTo(route, false);
  }

  toggleModal() {
    this.showModal = !this.showModal;
  }

  showError() {
    this.modalText = {
      header: "Error",
      body: "There was an error processing your request.",
    };
    this.showModal = true;
    setTimeout(() => this.modal.nativeElement.focus(), 0);
  }
}

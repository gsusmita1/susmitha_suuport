import {
  Component,
  OnInit,
  ElementRef,
  ViewChild,
  AfterViewInit,
  QueryList,
  ViewChildren,
} from "@angular/core";
import { NavigationEnd, Router } from "@angular/router";
import { filter } from "rxjs/operators";
import { AccountService } from "src/app/services/account.service";
import { RouterService } from "src/app/services/router.service";

@Component({
  selector: "app-account-management",
  templateUrl: "./account-management.component.html",
  styleUrls: ["./account-management.component.css"],
})
export class AccountManagementComponent implements OnInit, AfterViewInit {
  @ViewChildren("container")
  private containers: QueryList<any>;
  showAcctInfo: boolean = false;
  selectedApp: string;
  selectedField: string;
  personError: string;
  searchData: any = [
    { id: "accountId", name: "Account ID", value: null, active: true },
    { id: "ein", name: "EIN", value: null, active: true },
    { id: "ssn", name: "SSN", value: null, active: true },
  ];
  appTypes: any[] = [
    { name: "WCS", key: "W" },
    { name: "MSPRP", key: "M" },
    { name: "CRCP", key: "C" },
  ];
  searchFields: string[] = [];
  searchValue: string = "";

  accountInfo;
  fromUserAccess: boolean = false;
  fromVetSubmitters: boolean = false;

  appMap = { WCS: "WCS", MSPRP: "MRP", CRCP: "GHPRP" };
  fieldMap = {
    "Account ID": "accountId",
    EIN: "ein",
    SSN: "ssn",
  };
  fieldTextMap = {
    "": "Please select a search criteria",
    "Account ID": "Enter the Account ID",
    EIN: "Enter the EIN used during the account creation process",
    SSN: "Enter the SSN used during the account creation process",
  };

  constructor(private accountService: AccountService, private router: Router) {
    this.router.events
      .pipe(filter((event) => event instanceof NavigationEnd))
      .subscribe((event) => {
        if (this.router.getCurrentNavigation().extras.state) {
          this.searchValue =
            this.router.getCurrentNavigation().extras.state.accountId;
          this.selectedApp =
            this.router.getCurrentNavigation().extras.state.appName;
          this.fromUserAccess =
            this.router.getCurrentNavigation().extras.state.fromUserAccess;
          this.fromVetSubmitters =
            this.router.getCurrentNavigation().extras.state.fromVetSubmitters;
          this.selectedField = "Account ID";
          this.onContinue();
        } else {
          this.fromUserAccess = false;
        }
      });
  }

  ngOnInit(): void {
    this.setCriteriaOptions();
  }

  ngAfterViewInit() {
    if (this.containers.length) {
      //Will only fire once
      console.log({ viewInit: this.containers.first.nativeElement.innerText });
      this.containers.first.nativeElement.focus();
    }
  }

  onFromUserAccess() {}

  onContinue() {
    this.personError = null;
    if (!this.selectedApp) {
      this.personError = "Please select an application";
      return;
    }
    if (this.selectedField === "") {
      this.personError = "Please select a search criteria";
      return;
    }
    if (!this.searchValue) {
      this.personError = "Please enter a search term";
      return;
    }

    this.search(
      this.fieldMap[this.selectedField],
      this.searchValue,
      this.appMap[this.selectedApp] || this.selectedApp
    );
  }

  search(prop: string, value: string, appType: string) {
    this.accountService
      .accountInfoLookup(value, prop, appType)
      .subscribe((res) => {
        const result = res.result;
        if (!result || !result.submitterInfo) {
          this.personError = "Account not found";
        } else if (
          result &&
          result.submitterInfo &&
          typeof result.submitterInfo === "string"
        ) {
          this.personError = result.submitterInfo;
        } else {
          this.accountInfo = res.result;
          this.showAcctInfo = true;
          this.accountService.activeAccountInfo.next(res.result);
          this.accountService.activeAccountType.next(appType);
        }
      });
  }

  clearCriteria() {
    this.searchValue = null;
  }

  setCriteriaOptions() {
    this.searchData[2].active = this.selectedApp === "CRCP" ? false : true;
    this.searchFields = [];
    this.selectedField = "";
    Object.keys(this.searchData).forEach((key) => {
      if (this.searchData[key].active)
        this.searchFields.push(this.searchData[key].name);
    });
  }

  appTypeChanged() {
    this.clearCriteria();
    this.setCriteriaOptions();
  }

  getSearchFieldText() {
    return this.fieldTextMap[this.selectedField];
  }

  closeAccountInfo() {
    this.clearCriteria();
    this.selectedApp = null;
    this.showAcctInfo = false;
  }
}

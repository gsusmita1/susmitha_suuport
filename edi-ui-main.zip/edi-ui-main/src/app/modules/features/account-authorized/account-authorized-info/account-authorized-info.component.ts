import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  ElementRef,
  ViewChild,
  AfterViewInit,
  QueryList,
  ViewChildren,
} from "@angular/core";
import { RouterService } from "src/app/services/router.service";
import { ActivatedRoute, Router } from "@angular/router";
@Component({
  selector: "app-account-authorized-info",
  templateUrl: "./account-authorized-info.component.html",
  styleUrls: ["./account-authorized-info.component.css"],
})
export class AccountAuthorizedInfoComponent implements OnInit, AfterViewInit {
  @ViewChildren('container')
  private containers: QueryList<any>;
  @Input() authorizedRep: any = {};
  @Input() rreList: any = [];
  @Output() onCancel: EventEmitter<any> = new EventEmitter();
  @Output() onContinue: EventEmitter<any> = new EventEmitter();
  enableAddrInputs: boolean = false;

  constructor(
    private routerService: RouterService,
    private route: ActivatedRoute
  ) {}
  states = [
    { id: 1, code: "  ", name: "Not Defined" },
    { id: 2, code: "AK", name: "ALASKA" },
    { id: 3, code: "AL", name: "ALABAMA" },
    { id: 4, code: "AR", name: "ARKANSAS" },
    { id: 5, code: "AS", name: "AMERICAN SAMOA" },
    { id: 6, code: "AZ", name: "ARIZONA" },
    { id: 7, code: "CA", name: "CALIFORNIA" },
    { id: 8, code: "CO", name: "COLORADO" },
    { id: 9, code: "CT", name: "CONNECTICUT" },
    { id: 10, code: "DC", name: "DISTRICT OF COLUMBIA" },
    { id: 11, code: "DE", name: "DELAWARE" },
    { id: 12, code: "FL", name: "FLORIDA" },
    { id: 13, code: "GA", name: "GEORGIA" },
    { id: 14, code: "GU", name: "GUAM" },
    { id: 15, code: "HI", name: "HAWAII" },
    { id: 16, code: "IA", name: "IOWA" },
    { id: 17, code: "ID", name: "IDAHO" },
    { id: 18, code: "IL", name: "ILLINOIS" },
    { id: 19, code: "IN", name: "INDIANA" },
    { id: 20, code: "KS", name: "KANSAS" },
    { id: 21, code: "KY", name: "KENTUCKY" },
    { id: 22, code: "LA", name: "LOUISIANA" },
    { id: 23, code: "MA", name: "MASSACHUSETTS" },
    { id: 24, code: "MD", name: "MARYLAND" },
    { id: 25, code: "ME", name: "MAINE" },
    { id: 26, code: "MI", name: "MICHIGAN" },
    { id: 27, code: "MN", name: "MINNESOTA" },
    { id: 28, code: "MO", name: "MISSOURI" },
    { id: 29, code: "MP", name: "NORTHERN MARIANAS" },
    { id: 30, code: "MS", name: "MISSISSIPPI" },
    { id: 31, code: "MT", name: "MONTANA" },
    { id: 32, code: "NC", name: "NORTH CAROLINA" },
    { id: 33, code: "ND", name: "NORTH DAKOTA" },
    { id: 34, code: "NE", name: "NEBRASKA" },
    { id: 35, code: "NH", name: "NEW HAMPSHIRE" },
    { id: 36, code: "NJ", name: "NEW JERSEY" },
    { id: 37, code: "NM", name: "NEW MEXICO" },
    { id: 38, code: "NV", name: "NEVADA" },
    { id: 39, code: "NY", name: "NEW YORK" },
    { id: 40, code: "OH", name: "OHIO" },
    { id: 41, code: "OK", name: "OKLAHOMA" },
    { id: 42, code: "OR", name: "OREGON" },
    { id: 43, code: "PA", name: "PENNSYLVANIA" },
    { id: 44, code: "PR", name: "PUERTO RICO" },
    { id: 45, code: "RI", name: "RHODE ISLAND" },
    { id: 46, code: "SC", name: "SOUTH CAROLINA" },
    { id: 47, code: "SD", name: "SOUTH DAKOTA" },
    { id: 48, code: "TN", name: "TENNESSEE" },
    { id: 49, code: "TX", name: "TEXAS" },
    { id: 50, code: "UT", name: "UTAH" },
    { id: 51, code: "VA", name: "VIRGINIA" },
    { id: 52, code: "VI", name: "VIRGIN ISLANDS" },
    { id: 53, code: "VT", name: "VERMONT" },
    { id: 54, code: "WA", name: "WASHINGTON" },
    { id: 55, code: "WI", name: "WISCONSIN" },
    { id: 56, code: "WV", name: "WEST VIRGINIA" },
    { id: 57, code: "WY", name: "WYOMING" },
  ];
  selectedState;

  ngOnInit(): void {}
  ngOnChanges() {
    this.states.forEach((x) => {
      if (x.id === this.authorizedRep.stateId) {
        this.selectedState = x;
      }
    });
    console.log("selectedState", this.selectedState);
  }

  ngAfterViewInit() {
    if(this.containers.length){
      //Will only fire once
      console.log({viewInit: this.containers.first.nativeElement.innerText});
      this.containers.first.nativeElement.focus();
    }

    //So we subscribe to changes in the template when a certain condition(ngIf*) changes the DOM
    this.containers.changes.subscribe((elemRefs: QueryList<any>) => {
      if (elemRefs.length) {
        // here you get access only when element is rendered
        console.log({subscribed: elemRefs.first.nativeElement.innerText});
        elemRefs.first.nativeElement.focus();
      }
    });
  }


  onTabClose(event: any){
    console.log(event);
    if(event.index === 0){
      this.enableAddrInputs = false;
    }
  }

  onTabOpen(event: any){
    console.log(event);
    if(event.index === 0){
      this.enableAddrInputs = true;
    }
  }
}

interface State {
  id: number;
  name: string;
  code: string;
}

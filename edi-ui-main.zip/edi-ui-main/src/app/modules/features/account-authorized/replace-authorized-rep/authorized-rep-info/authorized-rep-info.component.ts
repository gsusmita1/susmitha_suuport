import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  ElementRef,
  ViewChild,
  AfterViewInit,
  QueryList,
  ViewChildren,
} from "@angular/core";
import {
  UntypedFormBuilder,
  FormControl,
  UntypedFormGroup,
  Validators,
} from "@angular/forms";
import { clone, cloneDeep } from "lodash";

import { EdiValidators } from "src/app/services/edi-validators";
import { Error } from "src/app/model/error.model";
import { ErrorMessagesService } from "src/app/modules/shared-modules/general/error-messages/error-messages.service";
import { ApiService } from "src/app/services/api.service";
import { DropDownService } from "src/app/services/drop-down.service";

import {
  AuthorizedRep,
  Representative,
} from "src/app/model/representative.interface";
import { State } from "src/app/model/state.interface";
import { FormService } from "src/app/services/form.service";

const ZIP54_PATTERN = /^[0-9]{5}?(-{1})?(\d{4})?\s{0,4}?(_{0,4})?$/;
const PHONE_EXTN_PATTERN =
  /^\(\d{3}\)\s\d{3}-\d{4}?\s?(x{1}\d{0,5})?\s{0,5}?(_{0,5})?$/;
const FAX_PATTERN = /^\(\d{3}\)\s\d{3}-\d{4}$/;
const UNDRSCORE_DASH_SPACE_PATTERN = /(_| |-)/g;

@Component({
  selector: "app-authorized-rep-info",
  templateUrl: "./authorized-rep-info.component.html",
  styleUrls: ["./authorized-rep-info.component.css"],
})
export class AuthorizedRepInfoComponent implements OnInit, AfterViewInit {
  @ViewChildren('container')
  private containers: QueryList<any>;
  @Input() newAuthorizedRep: AuthorizedRep;
  @Input() showNewAuthorizedRep: boolean;
  @Input() newArEmail: string;
  @Output() onContinue: EventEmitter<any> = new EventEmitter<any>();
  @Output() onCancel: EventEmitter<any> = new EventEmitter<any>();

  arInfoFormGroup: UntypedFormGroup;
  addressFormGroup: UntypedFormGroup; /* nested inside arInfoFormGroup */

  authorizedRep: AuthorizedRep;
  errorMsgs: Error[];
  stateList: State[];

  constructor(
    private apiService: ApiService,
    private dropDownService: DropDownService,
    private formService: FormService,
    public element: ElementRef,
    private formBuilder: UntypedFormBuilder
  ) {}

  ngOnInit() {
    this.stateList = this.dropDownService.getStateList();

    this.arInfoFormGroup = this.formBuilder.group({
      rreId: [""],
      rreCompanyName: [""],
      phone: [""],
      extn: [""],
      fax: [""],
      email: [""],
      firstName: ["", [Validators.required, EdiValidators.xss()]],
      lastName: ["", [Validators.required, EdiValidators.xss()]],
      jobTitle: ["", [Validators.required, EdiValidators.xss()]],
      phoneExtn: [
        "",
        [Validators.required, Validators.pattern(PHONE_EXTN_PATTERN)],
      ],
      faxMask: ["", [Validators.required, Validators.pattern(FAX_PATTERN)]],
      address: this.formBuilder.group({
        streetLine1: ["", [Validators.required, EdiValidators.xss()]],
        streetLine2: ["", [EdiValidators.xss()]],
        streetLine3: [""],
        streetLine4: [""],
        city: ["", [Validators.required, EdiValidators.xss()]],
        state: ["", [Validators.required]],
        zipcode: [""],
        zip10Mask: [
          "",
          [Validators.required, Validators.pattern(ZIP54_PATTERN)],
        ],
      }),
    });
    this.addressFormGroup = this.arInfoFormGroup.controls[
      "address"
    ] as UntypedFormGroup;

    //this.authorizedRep = new AuthRep();
    if (this.showNewAuthorizedRep) {
      //create and initialize an empty object to avoid undefined property error for address and zipcode

      this.authorizedRep = new AuthorizedRep({
        rreId: 0,
        rreCompanyName: "",
        email: this.newArEmail,
        firstName: "",
        lastName: "",
        jobTitle: "",
        phone: "",
        extn: "",
        fax: "",
        address: {
          streetLine1: "",
          streetLine2: "",
          streetLine3: "",
          streetLine4: "",
          city: "",
          state: "",
          zipcode: {
            zip5: "",
            zip4: "",
          },
        },
      });
    } else {
      this.authorizedRep = cloneDeep(this.newAuthorizedRep);
    }

    this.authorizedRep.email = this.newArEmail;
    this.arInfoFormGroup.setValue(this.authorizedRep);
    //p-InputMask control values have to be explicitly set
    this.arInfoFormGroup.controls["phoneExtn"].setValue(
      this.authorizedRep.phoneExtn
    );
    this.arInfoFormGroup.controls["faxMask"].setValue(
      this.authorizedRep.faxMask
    );
    this.addressFormGroup.controls["zip10Mask"].setValue(
      this.authorizedRep.address.zip10Mask
    );
    //console.log(this.arInfoForm.value);
  }

  ngAfterViewInit() {
    if(this.containers.length){
      //Will only fire once
      console.log({viewInit: this.containers.first.nativeElement.innerText});
      this.containers.first.nativeElement.focus();
    }

    //So we subscribe to changes in the template when a certain condition(ngIf*) changes the DOM
    this.containers.changes.subscribe((elemRefs: QueryList<any>) => {
      if (elemRefs.length) {
        // here you get access only when element is rendered
        console.log({subscribed: elemRefs.first.nativeElement.innerText});
        elemRefs.first.nativeElement.focus();
      }
    });
  }

  //called on continue button click
  continue() {
    this.errorMsgs = [];

    this.formService.touchControls(this.arInfoFormGroup);
    this.errorMsgs = this.formService.validateControlsAndGetList(
      this.arInfoFormGroup,
      ""
    );
    if (!this.arInfoFormGroup.controls["phoneExtn"].valid) {
      this.errorMsgs.push({
        detail: this.formService.getEmptyErrorMessageStd("phoneNumber"),
      });
    }
    if (!this.arInfoFormGroup.controls["faxMask"].valid) {
      this.errorMsgs.push({
        detail: this.formService.getEmptyErrorMessageStd("faxNumber"),
      });
    }

    this.formService.touchControls(this.addressFormGroup);
    let errorMsgs1: Error[] = this.formService.validateControlsAndGetList(
      this.addressFormGroup,
      ""
    );
    this.errorMsgs = this.errorMsgs.concat(errorMsgs1);

    if (!this.addressFormGroup.controls["zip10Mask"].valid) {
      this.errorMsgs.push({
        detail: this.formService.getEmptyErrorMessageStd("zipCode"),
      });
    }

    if (this.errorMsgs.length === 0) {
      console.log(this.arInfoFormGroup.value);
      let changedAuthRep: AuthorizedRep = AuthorizedRep.updateAuthorizedRep(
        this.authorizedRep,
        this.arInfoFormGroup.value
      );
      //p-InputMask control values have to be explicitly fetched
      changedAuthRep.phoneExtn =
        this.arInfoFormGroup.controls["phoneExtn"].value;
      changedAuthRep.faxMask = this.arInfoFormGroup.controls["faxMask"].value;
      changedAuthRep.address.zip10Mask =
        this.addressFormGroup.controls["zip10Mask"].value;
      console.log(changedAuthRep);
      //Take user to before-after change confirm page
      this.onContinue.emit({ newAuthorizedRep: changedAuthRep });
    }
  }

  cancel() {
    this.onCancel.emit({ newAuthorizedRep: { rreId: 0 } });
  }
}

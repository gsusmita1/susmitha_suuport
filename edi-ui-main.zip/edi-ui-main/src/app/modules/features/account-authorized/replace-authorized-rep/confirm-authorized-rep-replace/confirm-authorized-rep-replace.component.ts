import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  ElementRef,
  ViewChild,
  AfterViewInit,
  QueryList,
  ViewChildren,
} from "@angular/core";
import { Router } from "@angular/router";
import {
  AuthorizedRep,
  Representative,
} from "src/app/model/representative.interface";

@Component({
  selector: "app-confirm-authorized-rep-replace",
  templateUrl: "./confirm-authorized-rep-replace.component.html",
  styleUrls: ["./confirm-authorized-rep-replace.component.css"],
})
export class ConfirmAuthorizedRepReplaceComponent
  implements OnInit, AfterViewInit
{
  @ViewChildren('container')
  private containers: QueryList<any>;
  @ViewChild("modal", {}) modal: ElementRef;
  @Input() authorizedRep: AuthorizedRep;
  @Input() newAuthorizedRep: AuthorizedRep;
  @Input() rreList: Representative[];
  @Input() newRreList: Representative;
  @Output() onCancel: EventEmitter<any> = new EventEmitter<any>();
  @Output() onContinue: EventEmitter<any> = new EventEmitter<any>();

  showSuccessModal: boolean = false;

  constructor(private router: Router) {}

  ngOnInit() {}

  ngAfterViewInit() {
    if(this.containers.length){
      //Will only fire once
      console.log({viewInit: this.containers.first.nativeElement.innerText});
      this.containers.first.nativeElement.focus();
    }

    //So we subscribe to changes in the template when a certain condition(ngIf*) changes the DOM
    this.containers.changes.subscribe((elemRefs: QueryList<any>) => {
      if (elemRefs.length) {
        // here you get access only when element is rendered
        console.log({subscribed: elemRefs.first.nativeElement.innerText});
        elemRefs.first.nativeElement.focus();
      }
    });
  }

  onConfirm() {
    this.showSuccessModal = true;
    setTimeout(() => this.modal.nativeElement.focus(), 0);
  }

  cancel() {
    this.onCancel.emit({ newAuthorizedRep: this.newAuthorizedRep });
  }

  toggleSuccessModal() {
    this.showSuccessModal = false;
    this.onContinue.emit();
  }
}

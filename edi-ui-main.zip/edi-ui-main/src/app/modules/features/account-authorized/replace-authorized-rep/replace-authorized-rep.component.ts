import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  ElementRef,
  ViewChild,
  AfterViewInit,
  QueryList,
  ViewChildren,
} from "@angular/core";
import { Router, ActivatedRoute, ParamMap } from "@angular/router";
import { RepresentativeAddress } from "src/app/model/address.model";

import {
  AuthorizedRep,
  Representative,
} from "src/app/model/representative.interface";
import { ZipCode } from "src/app/model/zipcode.model";
import { RouterService } from "src/app/services/router.service";
import { Error } from "../../../../model/error.model";
import { ErrorMessagesService } from "../../../shared-modules/general/error-messages/error-messages.service";

const EMAIL_REGEXP =
  // tslint:disable-next-line:max-line-length
  /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

@Component({
  selector: "app-replace-authorized-rep",
  templateUrl: "./replace-authorized-rep.component.html",
  styleUrls: ["./replace-authorized-rep.component.css"],
})
export class ReplaceAuthorizedRepComponent implements OnInit, AfterViewInit {
  @ViewChildren('container')
  private containers: QueryList<any>;
  @Input() authorizedData: any = {};
  @Output() onCancel: EventEmitter<any> = new EventEmitter();
  @Output() onContinue: EventEmitter<any> = new EventEmitter();
  @Output() onConfirm: EventEmitter<any> = new EventEmitter();

  rreId: string = null;

  authorizedRep: AuthorizedRep = null;
  newAuthorizedRep: AuthorizedRep = null;

  showInfo: boolean = false;
  showNewAuthorizedRep: boolean = false;
  showReplacement: boolean = false;
  rreRequired: boolean = false;

  currentRreList: Representative[] = [];
  newRreList: Representative[] = [];
  newArEmail: string = "";

  errorMsgs: Error[];
  disableChkBox: boolean = false;

  constructor(
    private routerService: RouterService,
    private route: ActivatedRoute,
    private errorService: ErrorMessagesService
  ) {}

  ngOnInit(): void {
    //Call service to fetch RRE Details for currently Authorized Representative
    this.authorizedRep = new AuthorizedRep({
      rreId: 1234,
      firstName: "First",
      lastName: "Last",
      rreCompanyName: "",
      jobTitle: "MR AR",
      phone: "1234567890",
      extn: "123",
      fax: "9876543210",
      email: "mr_ar_ghp@test-team.cobqa.com",
      address: {
        streetLine1: "One West Pennsylvania Ave",
        streetLine2: "",
        city: "Towson",
        state: "MD",
        zipcode: { zip5: "21204", zip4: "" },
      },
    });

    this.currentRreList = [
      {
        rreCompanyName: "GHP B2BI Mailbox Test 2",
        rreId: 61186,
      },
      {
        rreCompanyName: "GHP B2BI Mailbox Test 3",
        rreId: 61188,
      },
      {
        rreCompanyName: "GHP B2BI Mailbox Test 4",
        rreId: 61190,
      },
      {
        rreCompanyName: "GHP B2BI Mailbox Test 5",
        rreId: 61204,
      },
      {
        rreCompanyName: "GHP B2BI Mailbox Test 6",
        rreId: 61206,
      },
      {
        rreCompanyName: "GHP B2BI Mailbox Test 7",
        rreId: 61208,
      },
    ];
  }

  ngAfterViewInit() {
    if(this.containers.length){
      //Will only fire once
      console.log({viewInit: this.containers.first.nativeElement.innerText});
      this.containers.first.nativeElement.focus();
    }

    //So we subscribe to changes in the template when a certain condition(ngIf*) changes the DOM
    this.containers.changes.subscribe((elemRefs: QueryList<any>) => {
      if (elemRefs.length) {
        // here you get access only when element is rendered
        console.log({subscribed: elemRefs.first.nativeElement.innerText});
        elemRefs.first.nativeElement.focus();
      }
    });
  }

  onTabClose(event: any){
    console.log(event);
    if(event.index === 1){
      this.disableChkBox = true;
    }
  }

  onTabOpen(event: any){
    console.log(event);
    if(event.index === 1){
      this.disableChkBox = false;
    }
  }

  cancel() {
    this.onCancel.emit();
  }

  continue() {
    this.errorMsgs = [];
    this.errorMsgs = this.isValid();
    if (this.errorMsgs.length === 0) {
      /*
        Call service to find out if:
        a. [email-id found]:
          take user to AR Info entry page where they will change existing data fetched for the
          authorized representative found for the email provided
          this.showNewAuthorizedRep = false;
        b. [email-id not-found]:
          take user to AR Info entry page where they will enter all required data
          this.showNewAuthorizedRep = true;
      */
      if (this.newArEmail === "abc@def.com") {
        //mimic a non-existing AR email for which user has to enter new data inside info page
        this.showNewAuthorizedRep = true;
      } else {
        //
        this.showNewAuthorizedRep = false;
        //mimic an existing AR email for which user has can change/update data pulled from db inside info page
        this.newAuthorizedRep = new AuthorizedRep({
          rreId: 7890,
          firstName: "Obi-Wan",
          lastName: "Knobi",
          rreCompanyName: "",
          jobTitle: "MR AR Found",
          phone: "5126789045",
          extn: "7767",
          fax: "7126543210",
          email: this.newArEmail,
          address: {
            streetLine1: "6th Street",
            streetLine2: "Party 101",
            streetLine3: "",
            streetLine4: "",
            city: "Austin",
            state: "TX",
            zipcode: { zip5: "78701", zip4: "2034" },
          },
        });
      }

      this.showInfo = true; // go to next page
    }
  }

  openConfirmReplacement(event) {
    this.newAuthorizedRep = event.newAuthorizedRep;
    this.showInfo = false;
    this.showReplacement = true;
    this.showNewAuthorizedRep = false;
  }

  cancelConfirmReplacement(event) {
    this.newAuthorizedRep = event.newAuthorizedRep;
    this.showInfo = true;
    this.showReplacement = false;
    this.showNewAuthorizedRep = false;
  }

  cancelShowArInfo(event) {
    this.newAuthorizedRep = event.newAuthorizedRep;
    this.showInfo = false;
    this.showReplacement = false;
  }

  isValid(): any[] {
    let errorMessages: any[] = [];
    /* email validation */
    if (
      !this.newArEmail ||
      (this.newArEmail &&
        (this.newArEmail.trim() === "" || !EMAIL_REGEXP.test(this.newArEmail)))
    ) {
      errorMessages.push({
        detail:
          "Please enter a valid e-mail address (i.e. UserID@domain.name).",
      });
    }
    if (
      this.newArEmail &&
      this.authorizedRep.email &&
      this.authorizedRep.email.trim() === this.newArEmail.trim()
    ) {
      errorMessages.push({
        detail: "Replacement Authorized Representative email cannot match.",
      });
    }

    /* rre-selection validation */
    if (!this.newRreList || this.newRreList.length === 0) {
      errorMessages.push({
        detail:
          "No RRE IDs have been selected. Please check at least one RRE ID before clicking Continue.",
      });
    }

    return errorMessages;
  }
}

import {
  Component,
  OnInit,
  ElementRef,
  ViewChild,
  AfterViewInit,
  QueryList,
  ViewChildren,
} from "@angular/core";
import { Router } from "@angular/router";
import { AccountService } from "src/app/services/account.service";

import { RouterService } from "src/app/services/router.service";

@Component({
  selector: "app-account-authorized",
  templateUrl: "./account-authorized.component.html",
  styleUrls: ["./account-authorized.component.css"],
})
export class AccountAuthorizedComponent implements OnInit, AfterViewInit {
  @ViewChildren('container')
  private containers: QueryList<any>;
  rreId: String;

  showSearch: boolean = true;
  showInfo: boolean = false;
  showReplace: boolean = false;
  showPreview: boolean = false;

  authorizedRep;
  rreList;
  personError: string = null;

  constructor(
    private routerService: RouterService,
    private router: Router,
    private accountService: AccountService
  ) {}
  city: any;
  authorizedData: any = {
    rreId: null,
    emailId: null,
  };

  ngOnInit(): void {}

  ngAfterViewInit() {
    if(this.containers.length){
      //Will only fire once
      console.log({viewInit: this.containers.first.nativeElement.innerText});
      this.containers.first.nativeElement.focus();
    }
  }

  onUpdate() {
    this.findAR(this.authorizedData, "update");
  }

  onReplace() {
    this.findAR(this.authorizedData, "replace");
  }

  findAR(criteria, action) {
    console.log("criteria:", criteria);
    this.personError = null;
    let value;
    let prop;
    if (criteria.rreId) {
      prop = "rreid";
      value = criteria.rreId;
      this.search(prop, value, action);
    } else if (criteria.emailId) {
      prop = "email";
      value = criteria.emailId;
      this.search(prop, value, action);
    } else {
      this.personError = "Invalid search criteria";
    }
  }

  search(prop, value, action) {
    this.accountService.accountRepLookup(value, prop).subscribe((response) => {
      if (typeof response.result.person === "string") {
        this.personError = "Authorized Representative not found";
      } else {
        const result = response.result;
        this.authorizedRep = result.person;
        this.rreList = result.rreList;
        if (action === "update") {
          this.showInfo = true;
          this.showSearch = false;
        } else if (action === "replace") {
          this.showReplace = true;
          this.showSearch = false;
        }
      }
    });
  }

  onCancel(view: string) {
    if (view === "info") {
      this.showInfo = false;
      this.showSearch = true;
    } else if (view === "preview") {
      this.showPreview = false;
      this.showInfo = true;
    } else if (view === "replace") {
      this.showReplace = false;
      this.showSearch = true;
    }
  }

  onContinue(view: string) {
    if (view === "info") {
      this.showInfo = false;
      this.showPreview = true;
    } else if (view === "preview") {
      this.showPreview = false;
      this.showSearch = true;
    } else if (view === "replace") {
      this.showReplace = false;
      this.showInfo = true;
    }
  }

  onConfirm() {
    this.showSearch = true;
    this.showReplace = false;
  }
}

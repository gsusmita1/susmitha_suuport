import {
  Component,
  Input,
  OnInit,
  Output,
  EventEmitter,
  ElementRef,
  ViewChild,
  AfterViewInit,
  QueryList,
  ViewChildren,
} from "@angular/core";
import { RouterService } from "src/app/services/router.service";
import { Router } from "@angular/router";
@Component({
  selector: "app-account-authorized-preview",
  templateUrl: "./account-authorized-preview.component.html",
  styleUrls: ["./account-authorized-preview.component.css"],
})
export class AccountAuthorizedPreviewComponent
  implements OnInit, AfterViewInit
{
  @ViewChildren('container')
  private containers: QueryList<any>;
  @Input() authorizedRep: any = {};
  @Input() currentRreList: any = [];
  @Output() onCancel: EventEmitter<any> = new EventEmitter();
  @Output() onContinue: EventEmitter<any> = new EventEmitter();

  constructor(private routerService: RouterService, private router: Router) {}

  ngOnInit(): void {
    this.authorizedRep = {
      rreId: 7890,
      firstName: "Jack",
      lastName: "Brown",
      jobTitle: "Executive",
      phone: "5126789045",
      extn: "7767",
      fax: "7126543210",
      email: "brown@gmail.com",
      address: {
        streetLine1: "1001 15th Street",
        streetLine2: "Suite 101",
        streetLine3: "",
        streetLine4: "",
        city: "Dallas",
        state: "TX",
        zipcode: {
          zip5: "75074",
          zip4: "2034",
        },
      },
    };

    this.currentRreList = [
      {
        rreCompanyName: "GHP B2BI Mailbox Test 2",
        rreId: 61186,
      },
      {
        rreCompanyName: "GHP B2BI Mailbox Test 3",
        rreId: 61188,
      },
      {
        rreCompanyName: "GHP B2BI Mailbox Test 4",
        rreId: 61190,
      },
      {
        rreCompanyName: "GHP B2BI Mailbox Test 5",
        rreId: 61204,
      },
      {
        rreCompanyName: "GHP B2BI Mailbox Test 6",
        rreId: 61206,
      },
      {
        rreCompanyName: "GHP B2BI Mailbox Test 7",
        rreId: 61208,
      },
    ];
  }

  ngAfterViewInit() {
    if(this.containers.length){
      //Will only fire once
      console.log({viewInit: this.containers.first.nativeElement.innerText});
      this.containers.first.nativeElement.focus();
    }

    //So we subscribe to changes in the template when a certain condition(ngIf*) changes the DOM
    this.containers.changes.subscribe((elemRefs: QueryList<any>) => {
      if (elemRefs.length) {
        // here you get access only when element is rendered
        console.log({subscribed: elemRefs.first.nativeElement.innerText});
        elemRefs.first.nativeElement.focus();
      }
    });
  }
}

import {
  Component,
  OnInit,
  ElementRef,
  ViewChild,
  AfterViewInit,
} from "@angular/core";
import { RouterService } from "src/app/services/router.service";
import { VettingService } from "src/app/services/vetting.services";
import * as moment from "moment-timezone";
import { Router } from "@angular/router";
@Component({
  selector: "app-submitters-requiring",
  templateUrl: "./submitters-requiring.component.html",
  styleUrls: ["./submitters-requiring.component.css"],
})
export class SubmittersRequiringComponent implements OnInit, AfterViewInit {
  @ViewChild("container", {}) container: ElementRef;

  // SBMT_SUB_TYPE = ‘P’ display as Professional Administrator

  constructor(
    private routerService: RouterService,
    private vettingService: VettingService,
    private router: Router
  ) {}
  submittersData: any[] = [];
  accountTypes = new Map([
    ["C", "Corporate"],
    ["R", "Representative"],
    ["S", "Self"],
  ]);

  ngOnInit(): void {
    this.vettingService.getVettingDetails().subscribe((res: any) => {
      this.submittersData = res.result;
    });
  }
  getSubmitType(item) {
    let type = this.accountTypes.get(item.sbmtType);
    if (type === "Corporate" && item.sbmtSubType === "P") {
      type = "Professional Administrator";
    }
    return type;
  }

  getSystemInd(item) {
    if (item.sbmtSystemInd === "W") return "WCASA";
    if (item.sbmtSystemInd === "M") return "MSPRP";
    return "";
  }

  formetDate(date: string) {
    return moment(date, "YYYYMMDD").format("MM/DD/yyyy");
  }

  ngAfterViewInit() {
    this.container.nativeElement.focus();
  }

  onCancel() {
    this.routerService.navigateTo("dashboard", false);
  }

  onAccountInfo(accountId: string, appName: string) {
    if (appName == "M") {
      appName = "MSPRP";
    } else {
      appName = "WCS";
    }
    const state = {
      accountId: accountId,
      appName: appName,
      fromVetSubmitters: true,
    };
    console.log(state);
    this.router.navigateByUrl("/accountManagement", { state: state });
  }
}

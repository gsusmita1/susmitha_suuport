import {
  Component,
  OnInit,
  ElementRef,
  ViewChild,
  AfterViewInit,
  Input,
  Output,
  EventEmitter,
  Renderer2,
} from "@angular/core";
import { ActivatedRoute, NavigationEnd, Router } from "@angular/router";
import { RouterService } from "src/app/services/router.service";
import { DashboardService } from "../../../services/dashboard.service";
import { ApiService } from "src/app/services/api.service";
import { ResponseService } from "src/app/services/response.service";
import { UntypedFormControl, UntypedFormGroup, Validators } from "@angular/forms";
import { FormService } from "src/app/services/form.service";
import { EdiValidators, HASLOWCASE, HASNUMMBER, HASSPCHAR, HASUPCASE, RESTRICTED_WORD_LIST } from "src/app/services/edi-validators";
import systemErrors from "src/app/services/system-errors";
import { environment } from "src/environments/environment";
import { Message } from "primeng/api";
import { SessionService } from "src/app/services/session.service";
import { filter } from "rxjs/operators";
import { PersonInfo } from "src/app/model/person-info.model";
import { EdiResponse } from "src/app/model/edi-respose.model";


@Component({
  selector: "app-reset-password",
  templateUrl: "./reset-password.component.html",
  styleUrls: ["./reset-password.component.css"],
})
export class ResetPasswordComponent implements OnInit, AfterViewInit {
  environmentUrl = environment.url;
  
  @ViewChild("container", {}) container: ElementRef;
  @ViewChild('continueButton', { static: true }) nextElementFocus: ElementRef;

  @Input() previousElementFocus: any;
  @Output() formData: EventEmitter<UntypedFormGroup> = new EventEmitter<UntypedFormGroup>();

  @ViewChild('loginPassGuidelines', { static: true }) passGuide: ElementRef;

  @ViewChild('passChar', { static: true }) passChar: ElementRef;
  @ViewChild('pass1LowCase', { static: true }) pass1LowCase: ElementRef;
  @ViewChild('pass1UpCase', { static: true }) pass1UpCase: ElementRef;
  @ViewChild('pass1Number', { static: true }) pass1Number: ElementRef;
  @ViewChild('pass1SpChar', { static: true }) pass1SpChar: ElementRef;
  @ViewChild('passNoReserved', { static: true }) passNoReserved: ElementRef;
  @ViewChild('passMatch', { static: true }) passMatch: ElementRef;
  @ViewChild('passOverlap', { static: true }) passOverlap: ElementRef;

  resetPasswordForm: UntypedFormGroup;
  currentPassword: UntypedFormControl;
  password: UntypedFormControl;
  rePassword: UntypedFormControl;

  isEDI: boolean = true;
  account: any = null;
  result: PersonInfo = null;
  loginId: string = null;

  errorMsgs: Message[];

  showReservedWords: boolean = false;
  reservedWords: string =
    "PASSWORD, WELCOME, CMS, HCFA, SYSTEM, MEDICARE, MEDICAID, TEMP, LETMEIN, GOD, SEX, MONEY, QUEST, 1234, F20ASYA, RAVENS, REDSKIN, ORIOLES, BULLETS, CAPITOL, TERPS, DOCTOR, 567890, 12345678, ROOT, BOSSMAN, JANUARY, FEBRUARY, MARCH, APRIL, MAY, JUNE, JULY, AUGUST, SEPTEMBER, OCTOBER, NOVEMBER, DECEMBER, SSA, FIREWALL, CITIC, ADMIN, UNISYS, PWD, SECURITY, 76543210, 43210, 098765, IRAQ, OIS, TMG, INTERNET, INTRANET, EXTRANET, ATT, LOCKHEED, LOCKH33D, SOCIAL, FACEBOOK, YOUTUBE, WINDOWS, STEELERS, PATRIOTS, COMPUTER, DILBERT, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY, SPRING, SUMMER, AUTUMN, FALL, WINTER, BACKUP, BUSINESS, FALCONS, BRONCOS, EAGLES, PANTHERS, DOLPHINS, JAGUARS, CHIEFS, TEXANS, RAMS, BEARS, BROWNS, LIONS, BENGALS, COWBOYS, CARDINAL, CHARGERS, RAIDERS, SAINTS, REDSOX, YANKEES, PIRATES, PHILLIES, HHS, BRAVES, NATIONAL, UNITED, STATES, TWITTER, MITRE, MARLINS, OILERS, WHITESOX, CUBS, DODGERS, GIANTS, ANGELS, DEVILS, DIAMOND, SEATTLE, HOLLYWOOD, ARIZONA, ALABAMA, ALASKA, ARKANSAS, COLORADO, DELAWARE, FLORIDA, GEORGIA, HAWAII, IDAHO, ILLINOIS, INDIANA, IOWA, KANSAS, KENTUCKY, MAINE, MARYLAND, MICHIGAN, MISSOURI, MONTANA, NEBRASKA, NEVADA, LASVEGAS, NEWYORK, OHIO, OKLAHOMA, OREGON, UTAH, VERMONT, VIRGINIA, WYOMING, ATLANTIC, PACIFIC, SANFRAN, REGIONAL, MACS, EDC, BOSTON, ATLANTA, CMSNET, MDCN, TAMPA, MIAMI, STLOUIS, CHICAGO, DETROIT, DENVER, HOUSTON, DALLAS, INDIANS, TIGERS, ROYALS, BREWERS, TWINS, MARINERS, RANGERS, BLUEJAYS, ROCKIES, ASTROS, PADRES, LAPTOP, MODEM, DELL, SOLARIS, UNIX, LINUX, IBM, ROUTER, SWITCH, SERVER, STAFF, GOOGLE, YAHOO, VERIZON, ISSO, CISO, HACKER, PROGRAM, CYBER, DESKTOP, ENTER, EXIT, UNION, PIV, NETWORK, DROID, IPAD, IPHONE, DANGER, STARWAR, STARTREK, VULCAN, KLINGON, SPOCK, KIRK, CAPTAIN, XMEN, FLASH, FRINGE, JEDI, HOLIDAY, OUTLOOK, VETERAN, ARMY, NAVY, MARINE, AIRFORCE, MAINFRAME, CDS, HP, LHM, FLEX, SESAME, POLICY, HCPCS, DME, HOD, INTEL, VIPS, VPN, CISCO, APPLE, SECURE, DISNEY, VACATION, LEXMARK, LAKERS, THUNDER, JAZZ, MAVERICKS, PHOENIX, SPURS, CELTICS, HEAT, MAGIC, BULLS, HAWKS, HORNETS, NUGGETS, BLAZERS, GRIZZLIES, BOBCATS, WIZARDS, WARRIORS, KINGS, CLIPPERS, KNICKS, NETS, RAPTORS, 76ERS, ROCKETS, PISTONS, BUCKS, PACERS, CAVALIERS, SUNS, TIMBERWOLVES";

  showSuccessModal: boolean = false;
  successMsg: string =
    "The user's password has been changed successfuly.  The user will receive an email containing their new password, which they will be required to use the next time they log into the COB Secure Website";
  ediSuccessMsg: string =
    "Your password has been changed successfully.  You will be required to use the new password the next time you log into the COB Secure Website.";

  constructor(
    public renderer: Renderer2,
    private routerService: RouterService,
    private router: Router,
    private dashboardService: DashboardService,
    private apiService: ApiService, 
    private responseService: ResponseService,
    private formService: FormService,
    private activeRoute: ActivatedRoute,
    private session: SessionService,
  ) {
    this.routerService.passwordIsEDI$.subscribe((res) => {
      this.isEDI = res;
      this.account = res ? null : this.dashboardService.getUserAccessAccount();
    });
  
    this.router.events
      .pipe(filter((event) => event instanceof NavigationEnd))
      .subscribe((event) => {
        if (this.router.getCurrentNavigation().extras.state) {
          if( this.router.getCurrentNavigation().extras.state.route == "resetExpiredPassword" ) {
            this.loginId =
              this.router.getCurrentNavigation().extras.state.loginId;
            this.errorMsgs = 
              this.router.getCurrentNavigation().extras.state.errors;
          }
          this.result = 
            this.router.getCurrentNavigation().extras.state.result;

        } else {
          this.result = null;
          this.loginId = this.session.getCurrentUser().userName;
        }
      });
  }

  ngOnInit(): void {
    
    this.reservedWords = RESTRICTED_WORD_LIST.join(", ");
    if( this.hideCurrentPassword() ) {
      this.currentPassword = new UntypedFormControl('', []);

    } else {
      this.currentPassword = new UntypedFormControl('', [Validators.required,
        EdiValidators.password("Current Password must contain a value.")]);
    }

    this.password = new UntypedFormControl('', [Validators.required,
      EdiValidators.minLength((this.isEDI ? 15 : 8), systemErrors['PASSWORD_TOO_SHORT']),
      EdiValidators.maxLength(150, systemErrors['error.generic.password.invalid']),
      EdiValidators.password(systemErrors['error.generic.password.invalid']),
      EdiValidators.reserved(systemErrors['PASSWORD_RESERVED_WORD']),
      EdiValidators.mainFieldEqualTo('password', systemErrors['error.generic.password.invalid']),
      EdiValidators.hasOverlap('currentPassword', systemErrors['PASSWORD_OVERLAPS'])
    ]);

    this.rePassword = new UntypedFormControl('', [Validators.required,
      EdiValidators.equalTo('password', systemErrors['error.generic.password.notEqual'])]);

    this.resetPasswordForm = new UntypedFormGroup({
      'currentPassword': this.currentPassword,
      'password': this.password,
      'rePassword': this.rePassword
    });

    this.resetPasswordForm.get('password').valueChanges.subscribe(
      value => {
        if (value) {
          if( this.hideCurrentPassword() ) { this.currentPassword.setValue("") };
          this.evaluate(this.passChar, (value.length >= (this.isEDI ? 15 : 8)));
          this.evaluate(this.pass1Number, HASNUMMBER.test(value));
          this.evaluate(this.pass1LowCase, HASLOWCASE.test(value));
          this.evaluate(this.pass1UpCase, HASUPCASE.test(value));
          this.evaluate(this.pass1SpChar, HASSPCHAR.test(value));
          this.evaluate(this.passNoReserved, !this.resetPasswordForm.get('password').getError('reserved'));
          this.evaluate(this.passMatch, (value === this.resetPasswordForm.get('rePassword').value));
          this.evaluate(this.passOverlap, !this.resetPasswordForm.get('password').getError('hasOverlap'));
        }
      });

      this.resetPasswordForm.get('rePassword').valueChanges.subscribe(
        value => {
          if (value) {
            this.evaluate(this.passMatch, (value === this.resetPasswordForm.get('password').value));
          }
        });
    this.activeRoute.url.subscribe(url => this.resetPasswordForm.reset()); // Reset component when navigate to different registration page

  }
  
  evaluate(element: ElementRef, expression) {
    if (expression) {
      this.renderer.removeClass(element.nativeElement, 'pi-times');
      this.renderer.removeClass(element.nativeElement, 'pi-minus');
      this.renderer.addClass(element.nativeElement, 'pi-check');
      this.renderer.setStyle(element.nativeElement, 'color', '#046b99');
    } else {
      this.renderer.removeClass(element.nativeElement, 'pi-minus');
      this.renderer.removeClass(element.nativeElement, 'pi-check');
      this.renderer.addClass(element.nativeElement, 'pi-times');
      this.renderer.setStyle(element.nativeElement, 'color', 'red');
    }
  }

  evaluateSub(element: ElementRef, expression) {
    if (expression) {
      this.renderer.removeClass(element.nativeElement, 'pi-times-circle');
      this.renderer.removeClass(element.nativeElement, 'pi-minus-circle');
      this.renderer.addClass(element.nativeElement, 'pi-check-circle');
      this.renderer.setStyle(element.nativeElement, 'color', '#046b99');
    } else {
      this.renderer.removeClass(element.nativeElement, 'pi-minus-circle');
      this.renderer.removeClass(element.nativeElement, 'pi-check-circle');
      this.renderer.addClass(element.nativeElement, 'pi-times-circle');
      this.renderer.setStyle(element.nativeElement, 'color', 'red');
    }
  }
  ngAfterViewInit() {
    console.log(this.container.nativeElement);
    this.container.nativeElement.focus();
  }

  toggleModal() {
    this.showReservedWords = !this.showReservedWords;
  }

  disableSubmit() {
    if (this.isEDI) {
      return !this.currentPassword.valid || !this.password.valid || !this.rePassword.valid
        ? true
        : false;
    } else {
      return !this.password.valid || !this.rePassword.valid ? true : false;
    }
  }

  hideCurrentPassword() {
    return !this.isEDI;
  }

  toggleSuccessModal() {
    if (this.showSuccessModal) {
      if (!this.isEDI) {
        this.dashboardService.setUserAccessAccount(this.account);
        this.routerService.navigateTo("dashboard", true);
      } else {
        this.router.navigate(["dashboard"]);
      }
    } else {
      this.showSuccessModal = !this.showSuccessModal;
    }
  }

  cancel() {
    if (!this.isEDI) this.dashboardService.setUserAccessAccount(this.account);
    this.routerService.navigateTo("dashboard", true);
  }

  onTab(event) {
   
  }

  onShiftTab(event) {
    event.preventDefault();
    let comp = this;

    if (event.target.id === 'logPassGuides') {
      if (this.previousElementFocus) {
        setTimeout(function () {
          // TODO this will only work if previous element is input mask
          comp.previousElementFocus.el.nativeElement.children[0].focus();
        }, 0);
      }
    }

  }

  onBlur(event) {
    this.formData.emit(this.resetPasswordForm);
  }

  onFocus(event) {
    let comp = this;
    if (event.target.id === "focusSwitch") {
      setTimeout(function () {
        comp.passGuide.nativeElement.focus();
      }, 0);
    }
  }

  submit() {
    this.errorMsgs = [];
    this.formService.touchControls(this.resetPasswordForm);
    let errorMap = this.formService.validateControlsAndGetMap(this.resetPasswordForm, '');
    
    console.log(JSON.stringify(errorMap, (key, value)=> {
      if(value instanceof Map) {
        return {
          dataType: 'Map',
          value: [...value]
        };
      } else {
        return value;
      }
    }));

    if (this.resetPasswordForm.get('rePassword').errors?.equalTo) {
      errorMap.get('rePassword').splice(0, 1);
      errorMap.get('rePassword').push({detail: systemErrors['error.generic.password.notEqual']});
    }

    this.errorMsgs.push(...this.formService.getErrorMapAsList(errorMap));

    if (this.errorMsgs.length === 0) {
      if( this.isEDI ) {
        this.apiService.updatePassword( this.loginId ,this.currentPassword.value, this.password.value).subscribe((resp) => {
          this.handleResp( resp );
        });
      } else {
        this.result.actionInfo.actionResetPwd = true;
        this.result.person.resetPassword = this.password.value;
        // reset password for user account
        this.dashboardService.sendPersonAction(this.result).subscribe((resp) => {
          this.handleResp( resp );
        });
      }
  
    }
  }

  handleResp( resp: EdiResponse ) : Message[] {
    let errors = this.handleErrors(resp.errors);

    if(errors.length === 0 && resp.status == 500) {
      errors.push( { detail: "A system error has occurred. Please contact the Coordination of Benefits Contractor at 1-800-999-1118 or TTY/TDD: 1-800-318-8782 for the hearing and speech impaired. A Customer Service Representative will direct your call to someone who can help you. Providing any information displayed below to the Customer Service Representative will be helpful."} );
      errors.push( { detail: "Error message: Technical Difficulties"} );
      errors.push( { detail: "Error token: " + resp.traceId } );
      errors.push( { detail: "Error time: " + new Date(resp.timestamp) } );
    }

    if (errors.length === 0) {
      this.toggleSuccessModal();
    } else {
      this.errorMsgs = errors;
    }

    return errors;
  }

  handleErrors( list: any[]): Message[] {
    let errors = [];
    if(list) {
      list.forEach((value) => {
        let msg = this.decodeError(value);
        if(msg) {
          errors.push( msg );
        }
      });
    }
    return errors;

  }

  decodeError(value: any): Message | null {
    switch( value) {
      case "PASSWORD_IN_HISTORY":
        return { detail: "The password you entered does not meet the password requirements. The password was used recently. Please re-enter another password." }
      case "PASSWORD_INVALID":
        return { detail: "The current password does not match. Please re-enter current password." }
      case "PASSWORD_TOO_SOON":
        return { detail: "The password you entered does not meet the password requirements. The password was changed recently. Please try again later." }
      case "PASSWORD_OVERLAPS":
        return { detail: "The password you entered does not meet the password requirements. The new password must contain minimum four (4) changed characters. Please try again later." }
    
      default:
        return null;
    }

  }

  closeDialog() {
    this.router.navigate(['dashboard']);
  }

  back() {
    this.router.navigate(['dashboard']);
  }


}

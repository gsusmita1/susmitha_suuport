import {
  Component,
  OnInit,
  Input,
  EventEmitter,
  Output,
  ElementRef,
  ViewChild,
  AfterViewInit,
} from "@angular/core";
import { Router } from "@angular/router";
import { AccountManagerService } from "src/app/services/account-manager.service";

@Component({
  selector: "app-confirm-account-manager-replacement",
  templateUrl: "./confirm-account-manager-replacement.component.html",
  styleUrls: ["./confirm-account-manager-replacement.component.css"],
})
export class ConfirmAccountManagerReplacementComponent
  implements OnInit, AfterViewInit
{
  @ViewChild("container", {}) container: ElementRef;
  @ViewChild("modal", {}) modal: ElementRef;
  @Input() accountManager;
  @Input() newAccountManager;
  @Input() rreInfo;
  @Input() accountId;
  @Input() appType;
  @Input() submitterInfo;
  @Input() personInfo;

  showSuccessModal: boolean = false;
  @Output() onCancelReplaceAccount: EventEmitter<any> = new EventEmitter();
  constructor(
    private router: Router,
    private amService: AccountManagerService
  ) {}

  ngOnInit() {}

  ngAfterViewInit() {
    this.container.nativeElement.focus();
  }
  ngOnChanges() {
    console.log("newAcctManager:", this.newAccountManager);
  }

  onConfirm() {
    let data = {
      submitterInfo: this.submitterInfo,
      personInfo: this.personInfo,

      newPersonInfo: this.newAccountManager.prsnId
        ? this.newAccountManager
        : {
            ...this.newAccountManager,
            emailAdr: this.newAccountManager.emailAdr,
            prsn1stName: this.newAccountManager.prsn1stName,
            prsnLastName: this.newAccountManager.prsnLastName,
          },
      passPhrase: this.newAccountManager.password1,
    };
    delete data["password1"];
    delete data["password2"];
    this.amService
      .replaceAccountManager(this.appType, data)
      .subscribe((res) => {
        this.showSuccessModal = true;
        setTimeout(() => this.modal.nativeElement.focus(), 0);
      });
  }

  onCancel() {
    this.onCancelReplaceAccount.emit("");
  }
  toggleSuccessModal() {
    this.showSuccessModal = false;
    this.router.navigate(["/dashboard"]);
  }
}

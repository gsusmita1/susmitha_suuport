import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  ElementRef,
  ViewChild,
  AfterViewInit,
} from "@angular/core";

@Component({
  selector: "app-account-manager-info",
  templateUrl: "./account-manager-info.component.html",
  styleUrls: ["./account-manager-info.component.css"],
})
export class AccountManagerInfoComponent implements OnInit, AfterViewInit {
  @ViewChild("container", {}) container: ElementRef;
  @Input() accountManager;
  @Input() rreInfo;
  @Input() accountId;
  @Output() onContinue: EventEmitter<any> = new EventEmitter<any>();

  newEmail: string = null;

  constructor() {}

  ngOnInit() {}

  ngAfterViewInit() {
    this.container.nativeElement.focus();
  }

  continue() {
    this.onContinue.emit(this.newEmail);
  }
}

import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  ElementRef,
  ViewChild,
  AfterViewInit,
} from "@angular/core";

@Component({
  selector: "app-new-account-manager",
  templateUrl: "./new-account-manager.component.html",
  styleUrls: ["./new-account-manager.component.css"],
})
export class NewAccountManagerComponent implements OnInit, AfterViewInit {
  @ViewChild("container", {}) container: ElementRef;
  @Input() newAccountManager: any;
  @Input() accountId: any;
  @Output() onContinue: EventEmitter<any> = new EventEmitter<any>();
  @Output() onCancelNewAccount: EventEmitter<any> = new EventEmitter();

  password1: string = null;
  password2: string = null;

  formError: boolean = false;
  constructor() {}

  ngOnInit() {}

  ngAfterViewInit() {
    this.container.nativeElement.focus();
  }

  isValid() {
    if (
      !this.password1 ||
      !this.password2 ||
      !this.newAccountManager.prsn1stName ||
      !this.newAccountManager.prsnLastName
    ) {
      return false;
    } else {
      return true;
    }
  }

  continue() {
    this.formError = false;
    if (
      !this.password1 ||
      !this.password2 ||
      !this.newAccountManager.prsn1stName ||
      !this.newAccountManager.prsnLastName ||
      this.password1 !== this.password2
    ) {
      this.formError = true;
    } else {
      let data = {
        ...this.newAccountManager,
        password1: this.password1,
        password2: this.password2,
      };
      this.onContinue.emit(data);
    }
  }

  onCancel() {
    this.onCancelNewAccount.emit();
  }
}

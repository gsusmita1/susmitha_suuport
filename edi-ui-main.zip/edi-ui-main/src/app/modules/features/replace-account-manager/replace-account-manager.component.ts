import {
  Component,
  OnInit,
  ElementRef,
  ViewChild,
  AfterViewInit,
} from "@angular/core";
import { Router } from "@angular/router";
import { AccountManagerService } from "src/app/services/account-manager.service";
import { EMAIL_REGEXP } from "src/app/services/edi-validators";
import systemErrors from "src/app/services/system-errors";

@Component({
  selector: "app-replace-account-manager",
  templateUrl: "./replace-account-manager.component.html",
  styleUrls: ["./replace-account-manager.component.css"],
})
export class ReplaceAccountManagerComponent implements OnInit, AfterViewInit {
  @ViewChild("container", {}) container: ElementRef;
  selectedAppType: string = "WCS";
  email: string = null;
  accountId: number = null;
  rreId: number = null;

  accountManager = null;
  newAccountManager = null;
  rreInfo = null;
  foundAccountId = null;

  isMRA: boolean = false;
  showInfo: boolean = false;
  showNewAccountManager: boolean = false;
  showReplacement: boolean = false;
  personError: string = null;
  personInfo: any = null;
  submitterInfo: any = null;
  newAmEmailError: string = null;
  newAmEmail: string = null;
  appTypeMap = { WCS: "WCS", MSPRP: "MRP", CRCP: "GHPRP", MRA: "MRA" };

  constructor(
    private router: Router,
    private amService: AccountManagerService
  ) {}

  ngOnInit() {}

  ngAfterViewInit() {
    this.container.nativeElement.focus();
  }

  isSearchDisabled() {
    if (this.selectedAppType === "CRCP" && !this.accountId) {
      return true;
    } else if (
      this.selectedAppType !== ("CRCP" && "MRA") &&
      !this.accountId &&
      !this.email
    ) {
      return true;
    } else if (this.selectedAppType === "MRA" && !this.rreId) {
      return true;
    } else {
      return false;
    }
  }

  resetSearchForm() {
    this.email = null;
    this.accountId = null;
    this.rreId = null;
    this.accountManager = null;
    this.showInfo = false;
    this.showReplacement = false;
    this.showNewAccountManager = false;
  }

  onSearch() {
    this.personError = null;
    this.newAmEmailError = null;
    this.showInfo = false;
    if (!this.validSearchCriteria()) return;
    // Retrieve current Account Manager data.
    this.currentAMInfoLookup();
  }

  validSearchCriteria(): boolean {
    if (this.selectedAppType === "WCS" || this.selectedAppType === "MSPRP") {
      // Neither Account Id Nor email id is entered
      if (!this.accountId && !this.email) {
        this.personError =
          "Please enter a valid Account ID or a valid Email Address.";
        return false;
      }
      // Both Account Id and email id are entered
      if (this.accountId && this.email) {
        this.personError =
          "Please enter either a Account ID or Email Address, but not both.";
        return false;
      }
      // Only Account Id is entered
      if (this.accountId && !this.email) {
        return this.isValidAccountId();
      }
      // Only Email is entered
      if (this.email && !EMAIL_REGEXP.test(this.email)) {
        this.personError = systemErrors["error.generic.email.invalid"];
        return false;
      }
    } else if (this.selectedAppType === "CRCP") {
      return this.isValidAccountId();
    } else if (this.selectedAppType === "MRA") {
      return this.isValidRreId();
    }

    return true;
  }

  private isValidAccountId(): boolean {
    if ((this.accountId && isNaN(this.accountId)) || !this.accountId) {
      this.personError = "Please enter a valid Account ID.";
      return false;
    }
    return true;
  }

  private isValidRreId(): boolean {
    if ((this.rreId && isNaN(this.rreId)) || !this.rreId) {
      this.personError = "Please enter a valid RRE ID.";
      return false;
    }
    return true;
  }

  private currentAMInfoLookup() {
    let searchCriteria: any = this.accountId || this.email || this.rreId;
    this.isMRA = this.selectedAppType === "MRA" && this.rreId ? true : false;

    this.amService
      .getCurrentAccountManagerData(
        this.appTypeMap[this.selectedAppType],
        searchCriteria,
        this.accountId ? false : true
      )
      .subscribe((response) => {
        const result = response.result;
        if (response.status === 200 && result) {
          // submitter info is only present in the response for Non-MRA apps search.
          if (!this.isMRA && typeof result.submitterInfo === "string") {
            this.personError = result.submitterInfo;
            return;
          }

          // reporterInfo info is only present in the response for MRA app type search.
          if (this.isMRA && typeof result.reporterInfo === "string") {
            this.personError = result.reporterInfo;
            return;
          }

          this.personInfo = result.personInfo;
          if (typeof this.personInfo === "string") {
            this.personError = this.personInfo;
          } else {
            this.accountManager = {
              firstName: this.personInfo.prsn1stName,
              lastName: this.personInfo.prsnLastName,
              email: this.personInfo.emailAdr,
              status: this.personInfo.vldtnStusDesc,
            };
            
            this.submitterInfo = !this.isMRA ? result.submitterInfo: null;
            this.foundAccountId = !this.isMRA
              ? this.submitterInfo?.id || this.submitterInfo?.sbmtrId
              : null;
            this.rreInfo = this.isMRA ? { id: this.rreId } : null;
            this.showInfo = true;
          }
        } else {
          this.personError =
            "Unknown Error Occurred while retrieving current account manager info.";
        }
      });
  }

  newAccountManagerLookup(event: string) {
    this.newAmEmailError = null;
    this.newAmEmail = event;
    console.log("newEmail: ", this.newAmEmail);
    if (!this.isNewEmailValid()) return;

    // Call gateway api
    this.amService
      .replaceAccountManagerEmail(
        this.appTypeMap[this.selectedAppType],
        this.newAmEmail
      )
      .subscribe((response) => {
        if (response.result) {
          const result = response.result;
          if (typeof result === "string") {
            this.newAmEmailError = result;
            return;
          } else {
            this.newAccountManager = result;
            if (result.prsnId) {
              this.showInfo = false;
              this.openConfirmReplacement(this.newAccountManager);
            } else {
              (this.newAccountManager.emailAdr = this.newAmEmail),
                (this.showInfo = false);
              this.showNewAccountManager = true;
            }
          }
        } else {
          this.newAmEmailError =
            "There was a problem getting new account manager info.";
        }
      });
  }

  private isNewEmailValid(): boolean {
    /* Validate the new email address entered */
    if (
      !this.newAmEmail ||
      (this.newAmEmail &&
        (this.newAmEmail.trim() === "" || !EMAIL_REGEXP.test(this.newAmEmail)))
    ) {
      this.newAmEmailError = systemErrors["error.generic.email.invalid"];
      return false;
    }

    if (
      this.newAmEmail &&
      this.accountManager &&
      this.accountManager.email &&
      this.accountManager.email.trim() === this.newAmEmail.trim()
    ) {
      this.newAmEmailError =
        "New e-mail address cannot match with the current Account Manager.";
      return false;
    }
    return true;
  }

  openConfirmReplacement(event) {
    this.newAccountManager = event;
    this.showNewAccountManager = false;
    this.showReplacement = true;
  }

  onCancelReplaceAccount(event: any) {
    this.showReplacement = false;
    this.showInfo = true;
    this.newAmEmailError = null;
  }

  onCancelNewAccount(event) {
    this.showNewAccountManager = false;
    this.showInfo = true;
    this.newAmEmailError = null;
  }

  onAppTypeChange() {
    this.personError = null;
    this.showInfo = false;
    this.accountManager = null;
    this.clearSearchCriteria();
  }

  clearSearchCriteria() {
    this.accountId = null;
    this.email = null;
    this.rreId = null;
  }
}

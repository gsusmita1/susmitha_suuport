import {
  Component,
  OnInit,
  ElementRef,
  ViewChild,
  AfterViewInit,
  QueryList,
  ViewChildren,
} from "@angular/core";
import { Router } from "@angular/router";
import { ConfirmationService } from "primeng/api";
import { EcrsService } from "src/app/services/ecrs.service";

@Component({
  selector: "app-ecrs-user-lookup",
  templateUrl: "./ecrs-user-lookup.component.html",
  styleUrls: ["./ecrs-user-lookup.component.css"],
})
export class EcrsUserLookupComponent implements OnInit, AfterViewInit {
  @ViewChild("container", {}) container: ElementRef;
  @ViewChild("modal", {}) modal: ElementRef;
  userId: string = null;
  userFound: boolean = false;
  contractorId: string = null;

  contractors: any[] = [];
  selectedContractors: any[] = [];

  showAddContractor: boolean = false;
  showConfirmation: boolean = false;
  showResponse: boolean = false;
  errorMessage: string = null;
  responseHeader: string = null;
  responseBody: string = null;
  responseError: boolean = false;

  constructor(
    private router: Router,
    private confirmationService: ConfirmationService,
    private ecrsService: EcrsService
  ) {}

  ngOnInit() {}

  ngAfterViewInit() {
    this.container.nativeElement.focus();
  }

  onContinue() {
    this.errorMessage = null;
    // Validate search criteria
    if (!this.validSearchCriteria()) return;

    // Call edi-gateway api to get the list of contractors for user
    this.getContractorsForUser();
  }

  validSearchCriteria(): boolean {
    if (!this.userId) {
      this.errorMessage = "Please enter a User Login ID.";
      return false;
    }
    this.userId = this.userId.toUpperCase();
    return true;
  }

  getContractorsForUser() {
    this.ecrsService.lookupContractorsByUserId(this.userId).subscribe((res) => {
      this.userFound = true;
      this.contractors = [];
      res.result.forEach((item) => {
        this.contractors.push({ contractorId: item.contractor });
      });

    });
  }

  onAddNew() {
    // Validate the contractor number entered
    if (!this.validateAddContractor()) return;

    // Call edi-gateway api
    this.ecrsService.addContractor(this.userId, this.contractorId).subscribe((res) => {
      if (res.status === 200 && res.result) {
        if (res.result.responseCd === "099") {
          // There are already 10 users associated to the contractor.
          this.errorMessage = "Contractor ID is already associated with maximum number of allowed users.";
          return;
        }
        this.contractors.push({ contractorId: res.result.contractorNo });
        this.showAddContractor = false;
      } else if (res.status != 200) {
        // Error occurred
        this.errorMessage = "Unknown error while adding upload authority to contractor.";
        return;
      }
    });

  }

  validateAddContractor(): boolean {

    if (!this.contractorId) {
      this.errorMessage = "Please enter a Contractor ID.";
      return false;
    }
    this.contractorId = this.contractorId.toUpperCase();
    if (Array.isArray(this.contractors)) {

        if (this.contractors.filter(
          (cnt) => cnt.contractorId === this.contractorId
        ).length > 0) {
          this.errorMessage = "Contractor ID already have authority. Please check the contractors list.";
          return false;
        }

        return true;
  }
}

  onShowAddContractor() {
    this.showAddContractor = true;
    this.contractorId = null;
    this.errorMessage = null;
    setTimeout(() => this.modal.nativeElement.focus(), 0);
  }

  revokeSelected() {
    this.showConfirm();
  }

  showConfirm() {
    this.confirmationService.confirm({
      message:
        "Are you sure you want to revoke this user's file upload and download authority for the selected contractors?",
      accept: () => {
        // Call edi-gateway api
        this.ecrsService.revokeContractors(this.userId, this.selectedContractors).subscribe((res) => {
          if (res.status === 200 && res.result) {
            // Fetch the refreshed list of contractors for the user
            this.getContractorsForUser();
            this.responseHeader = "File Upload/Download Revocation Successful";
            this.responseBody = "The user no longer has file upload and download authority for the selected contractors.";
            this.responseError = false;
          } else {
            // Error occurred
            this.responseHeader = "File Upload/Download Revocation Unsuccessful";
            this.responseBody = "Unknown error while revoking upload and download authority for the selected contractors.";
            this.responseError = true;
          }
          this.selectedContractors = [];
          this.showResponse = true;
          setTimeout(() => this.modal.nativeElement.focus(), 0);
        });
      },
      reject: () => {
        this.selectedContractors = [];
      },
    });
  }

  close() {
    this.showResponse = false;
    this.showAddContractor = false;
    this.responseError = false;
  }

  cancel() {
    this.userFound = false;
    this.contractors = [];
    this.userId = null;
    this.errorMessage = null;
  }
}

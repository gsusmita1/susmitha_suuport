import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  ElementRef,
  ViewChild,
  AfterViewInit,
} from "@angular/core";
import { AccountService } from "src/app/services/account.service";
import * as moment from "moment";
import { ExportService } from "src/app/services/export.service";
import { from } from "rxjs";

@Component({
  selector: "app-paperless-emails",
  templateUrl: "./paperless-emails.component.html",
  styleUrls: ["./paperless-emails.component.css"],
})
export class PaperlessEmailsComponent implements OnInit, AfterViewInit {
  @ViewChild("container", {}) container: ElementRef;
  @Input() accountInfo;
  @Input() appType;
  @Output() cancel = new EventEmitter();
  accountId;
  fromDate;
  toDate;
  results = [];
  errorString: string = "";

  appMap = { WCS: "WCS", MSPRP: "MRP", CRCP: "GHPRP" };

  constructor(
    private accountService: AccountService,
    private exportService: ExportService
  ) {}

  ngOnInit(): void {}

  ngOnChanges() {
    this.accountId = this.accountInfo.contactInfo.accountId;
  }

  ngAfterViewInit() {
    this.container.nativeElement.focus();
  }

  onCancel() {
    this.cancel.emit();
  }

  isDateValid(fromDate, toDate) {
    let validFromDate = moment(fromDate, "MM/DD/YYYY", true).isValid();
    let validToDate = moment(toDate, "MM/DD/YYYY", true).isValid();
    return validFromDate && validToDate ? true : false;
  }
  isDateRangeValid(fromDate, toDate) {
    let validFromDate = moment(fromDate, "MM/DD/YYYY", true).isValid();
    let validToDate = moment(toDate, "MM/DD/YYYY", true).isValid();
    return validFromDate && validToDate ? true : false;
  }

  search() {
    this.errorString = "";
    this.results = [];
    const fromDate = moment(this.fromDate).format("MM/DD/YYYY");
    const toDate = moment(this.toDate).format("MM/DD/YYYY");
    console.log(moment(toDate).diff(fromDate, "days", true));
    if (!this.isDateValid(fromDate, toDate)) {
      this.errorString = "Please enter a valid date.";
      return;
    }
    if (moment(fromDate).isAfter(toDate)) {
      this.errorString = "From Date cannot be greater than To Date";
      return;
    }
    if (moment(toDate).diff(fromDate, "days", true) > 182) {
      this.errorString =
        "Search cannot exceed 182 days. Please correct date(s) accordingly.";
      return;
    }

    this.accountInfo.actionInfo.actionPaperlessEmails = true;
    this.accountService
      .getPaperlessEmails(
        this.accountInfo,
        this.appMap[this.appType] || this.appType,
        this.accountId,
        fromDate,
        toDate
      )
      .subscribe((response) => {
        const rspList = response.result;
        if (!rspList.length) {
          this.errorString = "No results found";
        } else {
          this.results = rspList;
          console.log(this.results);
        }
        // this.results = this.generateMockData();
      });
  }

  downloadEmail(item: any) {
    this.accountService
      .downloadEmailImage(
        this.appMap[this.appType] || this.appType,
        item.emailImageId
      )
      .subscribe((response) => {
        console.log(response);
        const result = response.result;
        if (!result) {
          this.errorString = "Failed to download";
        } else {
          const base64Response = result.emailContent;
          this.exportService.exportBase64ToPdf(
            base64Response,
            item.emailImageId
          );
        }
      });
  }

  generateMockData() {
    return [
      {
        date: "12/02/2022",
        link: "https://www.africau.edu/images/default/sample.pdf",
        undeliverable: true,
      },
      {
        date: "12/03/2022",
        link: "https://www.africau.edu/images/default/sample.pdf",
        undeliverable: false,
      },
      {
        date: "12/04/2022",
        link: "https://www.africau.edu/images/default/sample.pdf",
        undeliverable: false,
      },
      {
        date: "12/05/2022",
        link: "https://www.africau.edu/images/default/sample.pdf",
        undeliverable: true,
      },
      {
        date: "12/06/2022",
        link: "https://www.africau.edu/images/default/sample.pdf",
        undeliverable: true,
      },
      {
        date: "12/07/2022",
        link: "https://www.africau.edu/images/default/sample.pdf",
        undeliverable: false,
      },
      {
        date: "12/07/2022",
        link: "https://www.africau.edu/images/default/sample.pdf",
        undeliverable: false,
      },
      {
        date: "12/08/2022",
        link: "https://www.africau.edu/images/default/sample.pdf",
        undeliverable: true,
      },
    ];
  }
}

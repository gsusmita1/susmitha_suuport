import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ElementRef,
  ViewChild,
  AfterViewInit,
} from "@angular/core";

@Component({
  selector: "app-ephi",
  templateUrl: "./ephi.component.html",
  styleUrls: ["./ephi.component.css"],
})
export class EphiComponent implements OnInit, AfterViewInit {
  @ViewChild("modal", {}) modal: ElementRef;
  @Input() displayEphi = false;
  @Output() displayEphiChange: EventEmitter<boolean> =
    new EventEmitter<boolean>();

  @Output() accepted: EventEmitter<boolean> = new EventEmitter<boolean>();

  constructor() {}

  ngOnInit(): void {}

  ngAfterViewInit() {
    this.modal.nativeElement.focus();
  }

  accept() {
    this.accepted.emit(true);
  }

  cancel() {
    this.displayEphiChange.emit(false);
  }
}

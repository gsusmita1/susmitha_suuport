import {
  Component,
  ElementRef,
  HostListener,
  Input,
  OnInit,
  Renderer2,
  ViewChild,
} from "@angular/core";
import { AuthService } from "../../../services/auth.service";
import { environment } from "../../../../environments/environment";
import { MenuItem } from "primeng/api";
import { Router } from "@angular/router";
import { SessionService } from "../../../services/session.service";
import { Person } from "src/app/model/person.model";
import { RouterService } from "src/app/services/router.service";
import { User } from "src/app/model/user.model";
import { Subscription } from "rxjs";

@Component({
  selector: "app-header",
  templateUrl: "./header.component.html",
  styleUrls: ["./header.component.css"],
})
export class HeaderComponent implements OnInit {
  environmentUrl = environment.url;

  toggleBanner = false;
  @ViewChild("headerButton") headerButton: ElementRef;
  @ViewChild("headerArea") headerArea: ElementRef;

  @ViewChild("overlay") overlay: ElementRef;
  @ViewChild("navigator") navigator: ElementRef;

  authenticated: boolean = false;
  theDate: Date = new Date();
  zone: string = "";

  items: MenuItem[] = [];

  current_user: User;

  fullName: string = "";
  authServiceSubscription: Subscription = null;

  constructor(
    private authService: AuthService,
    private session: SessionService,
    public renderer: Renderer2,
    private router: Router,
    private routerService: RouterService
  ) {}

  ngOnInit() {
    setInterval(() => {
      this.theDate = new Date();
    }, 60000);

    // start listening for authentication changes
    this.authServiceSubscription = this.authService.authenticated.subscribe(
      (authenticated) => {
        console.log("authentication changed:" + authenticated);
        this.authenticated = authenticated;
        this.pushMenuItems();
      }
    );
  }

  ngOnChanges(changes) {
    this.pushMenuItems();
  }

  getLogoutItems() {
    return {
      label: this.fullName,
      icon: "pi pi-fw pi-user",
      url: "",
      items: [
        // {
        //   label: "User Profile",
        //   icon: "pi pi-inbox",
        //   routerLink: ["/user-profile"],
        // },
        {
          label: "Change Password",
          icon: "pi pi-inbox",
          command: () => this.resetPassword(),
        },
        // { label: 'Security Questions', icon: 'pi pi-inbox', routerLink: ['/user-profile/security-questions'] },
        {
          label: "Logout",
          icon: "pi pi-sign-out",
          command: () => this.logout(),
        },
      ],
    };
  }

  pushMenuItems() {
    let info = {
      label: "User Guide",
      icon: "pi pi-info-circle",
      command: () => this.viewUserGuide(),
    };

    this.items = [info];

    this.items.push({ separator: true });
    this.current_user = this.session.getCurrentUser();
    if (this.authenticated && this.current_user) {
      console.log(
        "setting fullName:" +
          this.current_user.firstName +
          " " +
          this.current_user.lastName +
          " (" +
          this.current_user.userName +
          ")"
      );
      this.fullName =
        this.current_user.firstName +
        " " +
        this.current_user.lastName +
        " (" +
        this.current_user.userName +
        ")";
      let logout = this.getLogoutItems();
      this.items.push(logout);
    }

    /*
    if (this.authenticated) {
      this.items.push({ separator: true });
      this.current_user = this.session.getCurrentUser();
      if (this.current_user) {
        this.fullName = this.current_user.userName;
      }
      this.items.push(logout);
    }*/
  }

  toggle() {
    this.toggleBanner = !this.toggleBanner;
    this.renderer.setAttribute(
      this.headerButton.nativeElement,
      "aria-expanded",
      this.toggleBanner + ""
    );
    this.renderer.setAttribute(
      this.headerArea.nativeElement,
      "aria-hidden",
      !this.toggleBanner + ""
    );
  }

  menuClick() {
    this.renderer.addClass(this.overlay.nativeElement, "is-visible");
    this.renderer.addClass(this.navigator.nativeElement, "is-visible");
    this.renderer.removeStyle(this.navigator.nativeElement, "height");
  }

  menuClose() {
    this.renderer.removeClass(this.overlay.nativeElement, "is-visible");
    this.renderer.removeClass(this.navigator.nativeElement, "is-visible");
    this.renderer.setStyle(this.navigator.nativeElement, "height", "50px");
  }

  @HostListener("window:resize", ["$event"])
  onResize(event) {
    if (event.target.innerWidth > 951) {
      this.renderer.removeClass(this.overlay.nativeElement, "is-visible");
      this.renderer.removeClass(this.navigator.nativeElement, "is-visible");
    }
  }

  viewUserGuide() {
    window.open(
      this.environmentUrl + "/?q=user-guide/edi-user-guide",
      "_blank"
    );
  }

  resetPassword() {
    this.routerService.navigateTo("resetPassword", true);
  }

  async logout() {
    // do session.logout always before authService.logout
    await this.session.logout(false).finally(() => {
      this.authService.logout();
      this.router.navigate(["/"]);
    });
  }
}

import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { DashboardRoutingModule } from "./dashboard-routing.module";
import { DashboardComponent } from "./dashboard/dashboard.component";
import { UserTableComponent } from "./user-table/user-table.component";
import { DashboardModelComponent } from "./dashboard-model/dashboard-model.component";
import { DialogModule } from "primeng/dialog";
import { UserInformationComponent } from "./user-information/user-information.component";
import { PanelModule } from "primeng/panel";
import { DividerModule } from "primeng/divider";
import { TableModule } from "primeng/table";
import { AccordionModule } from "primeng/accordion";
import { ButtonModule } from "primeng/button";
import { MenuModule } from "primeng/menu";
import { DashboardService } from "../../services/dashboard.service";
import { FormsModule } from "@angular/forms";
import { GeneralModule } from "../shared-modules/general/general.module";
import { ConfirmDialogModule } from "primeng/confirmdialog";

@NgModule({
  declarations: [
    DashboardComponent,
    UserTableComponent,
    DashboardModelComponent,
    UserInformationComponent,
  ],
  imports: [
    CommonModule,
    GeneralModule,
    DashboardRoutingModule,
    DialogModule,
    TableModule,
    PanelModule,
    DividerModule,
    AccordionModule,
    ButtonModule,
    MenuModule,
    FormsModule,
    ConfirmDialogModule,
  ],
  providers: [DashboardService],
})
export class DashboardModule {}

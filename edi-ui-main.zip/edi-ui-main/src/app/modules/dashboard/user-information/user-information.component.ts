import {
  Component,
  Input,
  OnInit,
  ElementRef,
  ViewChild,
  AfterViewInit,
} from "@angular/core";

@Component({
  selector: "app-user-information",
  templateUrl: "./user-information.component.html",
  styleUrls: ["./user-information.component.css"],
})
export class UserInformationComponent implements OnInit, AfterViewInit {
  @ViewChild("container", {}) container: ElementRef;

  @Input() user: any;

  constructor() {}

  ngOnInit(): void {}

  ngAfterViewInit() {
    //this.container.nativeElement.focus();
  }
}

import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import { Router } from "@angular/router";
import { RouterService } from "src/app/services/router.service";

@Component({
  selector: "app-user-table",
  templateUrl: "./user-table.component.html",
  styleUrls: ["./user-table.component.css"],
})
export class UserTableComponent implements OnInit {
  @Input() accounts;
  @Output() onNavigateToAccount: EventEmitter<any> = new EventEmitter();

  constructor(private router: Router) {}

  ngOnInit(): void {}

  onAccountInfo(accountId, appName) {
    const state = { accountId, appName, fromUserAccess: true };
    this.onNavigateToAccount.emit(state);
  }
}

import {
  Component,
  OnInit,
  ElementRef,
  ViewChild,
  AfterViewInit,
} from "@angular/core";
import { Router } from "@angular/router";
import * as moment from "moment-timezone";
import { ConfirmationService, MenuItem } from "primeng/api";
import { RouterService } from "src/app/services/router.service";
import { DashboardService } from "../../../services/dashboard.service";
import { setAction } from "src/app/utils/object.util";

@Component({
  selector: "app-dashboard",
  templateUrl: "./dashboard.component.html",
  styleUrls: ["./dashboard.component.css"],
})
export class DashboardComponent implements OnInit, AfterViewInit {
  @ViewChild("container", {}) container: ElementRef;
  constructor(
    private router: Router,
    private routerService: RouterService,
    private dashboardService: DashboardService,
    private confirmationService: ConfirmationService
  ) {
    this.routerService.returnToUserAccess$.subscribe((res) => {
      if (res) {
        const user = this.dashboardService.getUserAccessAccount();
        if (user.loginId) {
          this.loginId = user.loginId;
        } else if (user.email) {
          this.email = user.email;
        }
        this.onContinue();
      }
    });
  }

  loginId: string = null;
  email: string = null;
  user = null;
  idProof: any = {};
  showIdProofDetails: boolean = false;
  userAccounts = null;
  menuItems = null;
  personError: string = null;
  result: any;

  isOpen: Boolean = false;
  infoMsg: String = "";

  loadPage: String = "";

  userStatusMap = {
    "1": "Pending",
    "2": "Active",
    "3": "Inactive",
    "4": "Locked",
  };

  mfaStatus = {
    C: "Complete",
    E: "ID Proofed",
    F: "Failed Phone",
    I: "Initial Process",
    P: "Pending Phone",
  };

  errorMap = {
    NOT_FOUND: "Search returned no results",
    MISSING_CRITERIA: "Please enter a Login ID or Email Address",
    INVALID_CRITERIA:
      "Please enter either a Login ID or Email Address, but not both",
  };

  accountDetails = [{ accountID: "29993", companyName: "Jrd" }];
  actions: MenuItem[] = [];

  ngOnInit(): void {}

  ngAfterViewInit() {
    console.log(this.container.nativeElement);
    this.container.nativeElement.focus();
  }
  onContinue() {
    this.personError = null;
    this.user = null;
    if (!this.checkIfValid()) return;
    let searchCriteria = this.loginId || this.email;
    this.dashboardService
      .userLookup(searchCriteria, this.loginId ? false : true)
      .subscribe((response) => {
        console.log(response.result);
        if (typeof response.result.person === "string") {
          this.personError = this.errorMap.NOT_FOUND;
        } else {
          this.result = response.result;
          const person = response.result.person;
          const qstnList = response.result.qstnList || [];
          const rreList = response.result.rreList;
          this.idProof = response.result.idProof;
          this.showIdProofDetails =
            response.result.displayInfo.showIdProofDetails;

          this.userAccounts = response.result.sbmtrList;
          this.user = {
            firstName: person.prsn1stName,
            middleName: person.prsnMdlInitlName,
            lastName: person.prsnLastName,
            loginId: person.loginId,
            lastLogin: person.lastLoginTs
              ? moment(person.lastLoginTs).format("MM/DD/YYYY")
              : "N/A",
            status: this.userStatusMap[person.vldtnStusId],
            phoneNumber: person.telNum,
            email: person.emailAdr,
            questions: qstnList,
          };
          this.buildMenuItems(response.result.displayInfo);
          this.dashboardService.setUserAccessAccount(this.user);
        }
      });
  }

  checkIfValid(): boolean {
    if (this.loginId && this.email) {
      this.personError = this.errorMap.INVALID_CRITERIA;
      return false;
    }
    if (!this.loginId && !this.email) {
      this.personError = this.errorMap.MISSING_CRITERIA;
      return false;
    }
    return true;
  }

  getStatusDate(status) {
    if (!status || status === "" || status === "Initial Process") {
      return "N/A";
    } else {
      return this.idProof.mfaStatusDate;
    }
  }

  buildMenuItems(displayInfo) {
    this.actions = [];
    Object.entries(displayInfo).forEach((item) => {
      const [key, value] = item;
      if (value) {
        switch (key) {
          case "optionResetPwd": {
            this.actions.push({
              label: "Reset Password",
              command: () => {
                this.onResetPassword();
              },
            });
            break;
          }
          case "optionRestartIdProof": {
            this.actions.push({
              label: "Restart ID Proofing",
              command: () => {
                this.restartIdProofing();
              },
            });
            break;
          }
          case "optionIdProofUser": {
            this.actions.push({
              label: "ID Proof User",
              command: () => {
                this.idProofUser();
              },
            });
            break;
          }
          case "optionUnlockUserAcct": {
            this.actions.push({
              label: "Unlock User Account",
              command: () => {
                this.onUnlockUserAccount();
              },
            });
            break;
          }
          case "optionReactivate": {
            this.actions.push({
              label: "Reactivate User Account",
              command: () => {
                this.reactivateConfirmModel();
              },
            });
            break;
          }
          case "optionSendToken": {
            this.actions.push({
              label: "Send Token",
              command: () => {
                this.onRedirect("resend-token");
              },
            });
            break;
          }
          default: {
            break;
          }
        }
      }
    });
  }

  onRedirect(routeName: String) {
    this.loadPage = routeName;
  }

  onResetPassword() {
    this.routerService.passwordIsEDI$.next(false);
    this.router.navigate(["resetPassword"], { state: { result: this.result }} );
  }

  onUnlockUserAccount() {
    setAction(this.result.actionInfo, 'actionUnlockUserAcct');
    this.dashboardService.sendPersonAction(this.result).subscribe((res) => {
      this.onSetOpen("unlock-user-account");
      this.onContinue();
    });
  }

  idProofUser() {
    setAction(this.result.actionInfo, 'actionIdProofUser');
    this.dashboardService.sendPersonAction(this.result).subscribe((res) => {
      this.onSetOpen("id-proofing");
      this.onContinue();
    });
  }

  restartIdProofing() {
    setAction(this.result.actionInfo, 'actionRestartIdProof');
    this.dashboardService.sendPersonAction(this.result).subscribe((res) => {
      this.onSetOpen("restart-id-proofing");
      this.onContinue();
    });
  }

  reactivateUser() {
    setAction(this.result.actionInfo, 'actionReactivate');
    this.dashboardService.sendPersonAction(this.result).subscribe((res) => {
      this.onSetOpen("confirm-reactivate");
      this.onContinue();
    });
  }

  reactivateConfirmModel() {
    this.confirmationService.confirm({
      header: "Confirm Reactivate Login ID",
      message:
        "<p>INFORMATION: If the Reactivate function is used the user must login to        the system with their current password. If the user does not know their        current password, the Reset function should be used instead. The Reset        function will allow you to set a temporary password to be used at the        next login attempt.</p><p>Are you sure you want to reactivate the Login ID?</p>",
      accept: () => {
        this.reactivateUser();
      },
      reject: () => {},
    });
  }
  onSetOpen(data: any) {
    this.infoMsg = data;
    this.isOpen = true;
  }

  onCloseModel() {
    this.isOpen = false;
    this.onCancel();
  }

  onCancel() {
    this.loadPage = "";
  }

  navigateToAccount(state) {
    this.router.navigate(["accountManagement"], { state });
  }
}

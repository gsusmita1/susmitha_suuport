import {
  Component,
  ElementRef,
  Inject,
  OnDestroy,
  OnInit,
} from "@angular/core";
import { Router } from "@angular/router";
import { UntypedFormControl, UntypedFormGroup, Validators } from "@angular/forms";
import { ApiService } from "../../../services/api.service";
import { SessionService } from "../../../services/session.service";
import { AuthService } from "../../../services/auth.service";
import { TimeoutService } from "../../../services/timeout.service";
import { Constants } from "../../../services/constants";
import { Error } from "../../../model/error.model";
import { Title } from "@angular/platform-browser";
import { ErrorMessagesService } from "../../shared-modules/general/error-messages/error-messages.service";
import { FormService } from "../../../services/form.service";
import { ResponseService } from "../../../services/response.service";
import { DOCUMENT, Location } from "@angular/common";
import { environment } from "../../../../environments/environment";
import { EdiValidators } from "../../../services/edi-validators";
import { AuthorizationService } from "src/app/services/authorization.service";

@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"],
})
export class LoginComponent implements OnInit, OnDestroy {
  loginForm: UntypedFormGroup;
  loginId: UntypedFormControl;
  password: UntypedFormControl;
  mfaToken: UntypedFormControl;

  errorMsgs: Error[];

  userAccessFlow: string = "";
  showEmailSuccess: boolean;

  constructor(
    private router: Router,
    private apiService: ApiService,
    private responseService: ResponseService,
    private authService: AuthService,
    private sessionService: SessionService,
    private timeoutService: TimeoutService,
    private _location: Location,
    private constants: Constants,
    private formService: FormService,
    private element: ElementRef,
    private titleService: Title,
    private errorService: ErrorMessagesService,
    @Inject(DOCUMENT) private document: any,
    private permission: AuthorizationService
  ) {}

  ngOnInit() {
    this.titleService.setTitle("Login | EDI");
    this.loginId = new UntypedFormControl(null, [
      Validators.required,
      EdiValidators.whitespace(),
    ]);
    this.password = new UntypedFormControl(null, Validators.required);
    this.mfaToken = new UntypedFormControl(null, {
      validators: [Validators.required, Validators.minLength(6)],
    });
    this.loginForm = new UntypedFormGroup(
      {
        loginId: this.loginId,
        password: this.password,
        mfaToken: this.mfaToken,
      },
      { updateOn: "blur" }
    );
  }

  onSubmit() {
    // There is no session yet
    this.authService.logout(); // Logout from previous session if there is one
    this.errorService.clear();
    this.errorMsgs = [];

    this.formService.touchControls(this.loginForm);

    this.errorMsgs = this.formService.validateControlsAndGetList(
      this.loginForm,
      "login"
    );

    if (this.errorMsgs.length === 0) {
      let loginData = {
        username: this.loginForm.get("loginId").value,
        password: this.loginForm.get("password").value,
        mfaToken: this.loginForm.get("mfaToken").value,
      };

      this.apiService.doLogin(loginData).subscribe((resp) => {
              
        let errorsTemp = this.responseService.validateResponse(resp);
        let data = resp.result;
        console.log("doLogin response: " + JSON.stringify(data["user"]));  
        this.sessionService.setCurrentUser(data["user"]);

        if (errorsTemp.length === 0) {
          this.authService.setToken(data["token"]);
          this.authService.setRefreshToken(data["refreshToken"]);
          // this.router.navigate(['login', 'warning']);
          this.authService.setAuthenticated(true);
          this.permission.initializePrivileges().subscribe(() => {
            this.router.navigate(["/dashboard"]);
          });
        } else {
          this.validateErrorResponse(errorsTemp, data);
          this.formService.resetForm(this.loginForm);
        }
      });
    }
  }

  validateErrorResponse(errors: any[], data: any) {
    console.log(JSON.stringify(errors[0]));

    if (errors[0].key === this.constants.USER_MUST_RESET_PASSWORD ||
          errors[0].key === this.constants.PASSWORD_EXPIRED ) {
      // PW EXPIRED
      this.router.navigate(["resetExpiredPassword"], {state: { route: "resetExpiredPassword", loginId: this.loginForm.get("loginId").value, errors: errors}});
    } else {
      this.errorMsgs = errors;
    }
  }

  forgotUsername() {
    this.router.navigate([
      "validatePersonInfo",
      this.constants.FORGOT_LOGIN_ID,
    ]);
  }

  forgotPassword() {
    this.router.navigate([
      "validatePersonInfo",
      this.constants.FORGOT_PASSWORD_NO_PIN,
    ]);
  }

  goToCob() {
    this.document.location.href = environment.url;
  }

  ngOnDestroy() {
    this.errorService.clear();
  }
}

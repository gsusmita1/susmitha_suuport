import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {SessionService} from '../../../services/session.service';
import {PersonSecurityDetail} from '../../../model/personSecurityDetail.model';
import { User } from 'src/app/model/user.model';

@Component({
  selector: 'app-welcome-back',
  templateUrl: './welcome-back.component.html',
  styleUrls: ['./welcome-back.component.css']
})
export class WelcomeBackComponent implements OnInit {

  user: User;
  firstTime = false;
  failedAttempts = false;
  multipleAttempts = false;

  // securityDetails: PersonSecurityDetail;

  loginAttempts: number = 0;

  constructor(private router: Router, private session: SessionService) {
  }

  ngOnInit() {
    this.user = this.session.getCurrentUser();
    // this.securityDetails = this.user.personSecurityDetail;

    if (this.user.loginTimeStamp) {
      this.firstTime = false;
    } else {
      this.firstTime = true;
    }

    this.loginAttempts = this.user.badPwdCount;
    this.failedAttempts = this.loginAttempts > 0;
    this.multipleAttempts = this.loginAttempts > 1;
  }

  continueToPsList() {
    this.router.navigate(['/home']);
  }

}

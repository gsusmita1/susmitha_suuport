import { ZipCode } from "./zipcode.model";

const UNDRSCORE_DASH_SPACE_PATTERN  = /(_| |-)/g;

export class Address {
  streetLine1: string = '';
  streetLine2?: string = '';
  streetLine3?: string = '';
  streetLine4?: string = '';
  city: string = '';
  state: string = '';
  zipcode: ZipCode = new ZipCode('','');
}

export class RepresentativeAddress extends Address{
  constructor(data: Address){
    super();
    this.streetLine1 = data.streetLine1;
    this.streetLine2 = data.streetLine2;
    this.streetLine3 = data.streetLine3;
    this.streetLine4 = data.streetLine4;
    this.city = data.city;
    this.state = data.state;
    this.zipcode = new ZipCode(data.zipcode.zip5, data.zipcode.zip4);
    this.zip10Mask = RepresentativeAddress.generateZip10Mask(data.zipcode.zip5, data.zipcode.zip4);
  }

  public get zip10Mask() {
    let zipcode =  this.zipcode.zip5;
    if(this.zipcode.zip4){
      zipcode = this.zipcode.zip5 + "-" + this.zipcode.zip4;
    }
    return zipcode;
  }
  public set zip10Mask(zip10MaskVal: string) {
    /*
      With zip4:78728-1122
      No-Zip4:  21204- form=21204-
    */
      if( zip10MaskVal.length > 5){
        this.zipcode.zip4 = zip10MaskVal.substring(6);
        this.zipcode.zip5 = zip10MaskVal.substring(0,5);
      } else {
        this.zipcode.zip4 = "";
        this.zipcode.zip5 = zip10MaskVal.substring(0,5);
      }

      this.zipcode.zip4 = this.zipcode.zip4.replace(UNDRSCORE_DASH_SPACE_PATTERN,"");
      this.zipcode.zip5 = this.zipcode.zip5.replace(UNDRSCORE_DASH_SPACE_PATTERN,"");
  }

  //generates mask to represent Phone(without extension) and Fax using p-InputMask
  static generateZip10Mask(zip5: string, zip4: string): string{
    let zipcode =  zip5;
    if(zip4){
      zipcode = zip5 + "-" + zip4;
    }
    return zipcode;
  }

  /*toAddress(): Address {
    return {
      streetLine1: this.streetLine1,
      streetLine2: this.streetLine2,
      streetLine3: this.streetLine3,
      streetLine4: this.streetLine4,
      city: this.city,
      state: this.state,
      zipcode: {
        zip5: this.zipcode.zip5,
        zip4: this.zipcode.zip4
      },
    };
  }*/
}

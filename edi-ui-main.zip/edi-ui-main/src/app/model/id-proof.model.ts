export class IdProof {
  public systemIndicator = 'E';
  public action= 'I';
  public personId = 0;
  public sbmtrId= '';
  public mfaStatus= '';
  public failedCount= '';
  public referenceNumber= '';
  public failedDate= '';
  public failedReason= '';
  public email= '';
  public mfaStatusDescription= '';
  public mfaStatusDate= '';
}

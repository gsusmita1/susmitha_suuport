export class User
{
    personId: number = 0;
    firstName?: string;
    middleName?: string;
    lastName?: string;
    userName: string = '';
    email: string | null;
    loginTimeStamp: Date | null;
    badPwdCount: number = 0;
    badPasswordTime: number;
    lockoutTime: number;
    pwdLastSet: number;
    memberOf: []|undefined;
    roleId: number;
}

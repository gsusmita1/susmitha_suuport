
export class ZipCode {
  zip5: string = '';
  zip4?: string = '';

  constructor(zip5: string, zip4: string){
    this.zip5= zip5;
    this.zip4= zip4;
  }
}

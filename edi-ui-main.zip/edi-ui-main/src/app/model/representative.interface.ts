import { ElementSchemaRegistry } from "@angular/compiler";
import { Address, RepresentativeAddress } from "./address.model";

const ZIP54_PATTERN                 = /^[0-9]{5}?(-{1})?(\d{4})?\s{0,4}?(_{0,4})?$/;
const PHONE_EXTN_PATTERN            = /^\(\d{3}\)\s\d{3}-\d{4}?\s?(x{1}\d{0,5})?\s{0,5}?(_{0,5})?$/;
const FAX_PATTERN                   = /^\(\d{3}\)\s\d{3}-\d{4}$/;
const UNDRSCORE_DASH_SPACE_PATTERN  = /(_| |-)/g;

export interface Representative {
  rreId: number;
  firstName?: string;
  lastName?: string;
  rreCompanyName?: string;
  jobTitle?: string;
  phone?: string;
  extn?: string;
  fax?: string;
  email?: string;
  address?: Address;
}

export class AuthorizedRep implements Representative {
  rreId: number;
  firstName?: string;
  lastName?: string;
  rreCompanyName?: string;
  jobTitle?: string;
  phone?: string;
  extn?: string;
  //phoneExtnMask?:string;
  fax?: string;
  email?: string;
  address?: RepresentativeAddress;

  constructor(data: Representative){
    if(data){
      this.rreId = data.rreId;
      this.firstName = data.firstName;
      this.lastName = data.lastName;
      this.rreCompanyName = data.rreCompanyName;
      this.jobTitle = data.jobTitle;
      this.phone = data.phone;
      this.extn = data.extn;
      this.phoneExtn = AuthorizedRep.generatePhoneExtnMask(data.phone, data.extn);
      this.fax = data.fax;
      this.faxMask =  AuthorizedRep.generatePhoneFaxMask(data.fax);
      this.email = data.email;
      this.address = new RepresentativeAddress(data.address);
    }
  }

  public get phoneExtn(): string {
    return AuthorizedRep.generatePhoneExtnMask(this.phone, this.extn);
  }
  public set phoneExtn(maskedPhoneExtn: string) {
    if(maskedPhoneExtn){
      if( maskedPhoneExtn.length > 10){
        let extnLoc:number = maskedPhoneExtn.indexOf("x");
        if( extnLoc > -1){
          this.extn = maskedPhoneExtn.substring(extnLoc+1);
          this.phone = maskedPhoneExtn.substring(0, extnLoc-1);
        }  else {
          this.extn = maskedPhoneExtn.substring(10);
          this.phone = maskedPhoneExtn.substring(0, 10);
        }
      } else {
        this.extn = "";
        this.phone = maskedPhoneExtn.substring(0, 15);
      }
      this.phone = this.phone.replace(UNDRSCORE_DASH_SPACE_PATTERN,"")
                             .replace("(","")
                             .replace(")","");
      this.extn = this.extn.replace(UNDRSCORE_DASH_SPACE_PATTERN,"");
    }
  }

  public get faxMask(): string {
    return AuthorizedRep.generatePhoneFaxMask(this.fax);
  }
  public set faxMask(maskedFaxNum: string) {
    this.fax = maskedFaxNum.replace(UNDRSCORE_DASH_SPACE_PATTERN,"")
                            .replace("(","")
                            .replace(")","");
  }

  //generates mask to represent Phone(without extension) and Fax using p-InputMask
  static generatePhoneFaxMask(numVal: string): string{
    if(numVal){
      if(numVal.length==10){
        return "(" + numVal.slice(0,3) + ") " + numVal.slice(3,6) + "-" + numVal.slice(6,10);
      }
    }

    return "";
  }
  static generatePhoneExtnMask(phoneNum: string, extension: string): string{
    if(phoneNum){
      let phoneNumWithExtn = AuthorizedRep.generatePhoneFaxMask(phoneNum);
      if(extension){
        phoneNumWithExtn = AuthorizedRep.generatePhoneFaxMask(phoneNum) + " x" + extension;
      }
      return phoneNumWithExtn;
    }

    return "";
  }

  /*
  public toRepresentative(): Representative {
    return {
      rreId: 0,
      email: this.email,
      firstName: this.firstName,
      lastName: this.lastName,
      jobTitle: this.jobTitle,
      phone: this.phone,
      extn: this.extn,
      fax: this.fax,
      address: this.address
    };
  }*/

  static updateAuthorizedRep(origData: AuthorizedRep, objData: Object): AuthorizedRep {
    if(origData && objData){
      let newData = objData as AuthorizedRep;
      origData.rreId = newData.rreId;
      origData.firstName = newData.firstName;
      origData.lastName = newData.lastName;
      origData.rreCompanyName = newData.rreCompanyName;
      origData.jobTitle = newData.jobTitle;
      origData.phone = newData.phone;
      origData.extn = newData.extn;
      origData.phoneExtn = AuthorizedRep.generatePhoneExtnMask(newData.phone, newData.extn);
      origData.fax = newData.fax;
      origData.faxMask =  AuthorizedRep.generatePhoneFaxMask(newData.fax);
      origData.email = newData.email;
      origData.address = new RepresentativeAddress(newData.address);
    }

    return origData;
  }
}

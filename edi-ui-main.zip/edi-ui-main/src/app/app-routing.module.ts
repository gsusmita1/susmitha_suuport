import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AuthGuard } from "./services/guards/auth-guard.service";
import { LoginComponent } from "./modules/main/login/login.component";
import { NotFoundComponent } from "./modules/main/not-found/not-found.component";
import { LoginWarningComponent } from "./modules/main/login-warning/login-warning.component";
import { ServerErrorComponent } from "./modules/main/server-error/server-error.component";
import { SessionExpiredComponent } from "./modules/main/session-expired/session-expired.component";
import { VersionComponent } from "./modules/main/version/version.component";
import { SessionExceptionComponent } from "./modules/main/session-exception/session-exception.component";
import { ResetPasswordComponent } from "./modules/features/reset-password/reset-password.component";
import { SubmittersRequiringComponent } from "./modules/features/submitters-requiring/submitters-requiring.component";
import { EcrsUserLookupComponent } from "./modules/features/ecrs-user-lookup/ecrs-user-lookup.component";
import { VetSubmitterComponent } from "./modules/features/vet-submitter/vet-submitter.component";
import { EcrsContractorLookupComponent } from "./modules/features/ecrs-contractor-lookup/ecrs-contractor-lookup.component";
import { RegenerateProfileComponent } from "./modules/features/regenerate-profile/regenerate-profile.component";
import { AccountAuthorizedComponent } from "./modules/features/account-authorized/account-authorized.component";
import { AccountManagementComponent } from "./modules/features/account-management/account-management.component";
import { RemoveInvalidSubmitterComponent } from "./modules/features/remove-invalid-submitter/remove-invalid-submitter.component";
import { GrantFullFunctionComponent } from "./modules/features/grant-full-function/grant-full-function.component";
import { PaperlessEmailsComponent } from "./modules/features/paperless-emails/paperless-emails.component";
import { PaperlessPartiesComponent } from "./modules/features/paperless-parties/paperless-parties.component";
import { ReplaceAccountManagerComponent } from "./modules/features/replace-account-manager/replace-account-manager.component";

const appRoutes: Routes = [
  { path: "", component: LoginWarningComponent, title: "Login Warning | EDI" },

  {
    path: "user-profile",
    loadChildren: () =>
      import("./modules/user/user.module").then((m) => m.UserModule),
    canLoad: [AuthGuard],
    title: "User Profile | EDI",
  },
  {
    path: "dashboard",
    loadChildren: () =>
      import("./modules/dashboard/dashboard.module").then(
        (m) => m.DashboardModule
      ),
    canLoad: [AuthGuard],
    title: "User Access Lookup | EDI",
  },
  {
    path: "bulletinBoard",
    loadChildren: () =>
      import("./modules/features/bulletin-board/bulletin-board.module").then(
        (m) => m.BulletinBoardModule
      ),
    canLoad: [AuthGuard],
    title: "Bulletin Board | EDI",
  },
  {
    path: "resetPassword",
    component: ResetPasswordComponent,
    canActivate: [AuthGuard],
    title: "Reset Password | EDI",
  },
  {
    path: "resetExpiredPassword",
    component: ResetPasswordComponent,
    title: "Reset Expired Password | EDI",
  },
  {
    path: "accountAuthorized",
    component: AccountAuthorizedComponent,
    canActivate: [AuthGuard],
    title: "Change Authorized Representative | EDI",
  },
  {
    path: "accountManagement",
    component: AccountManagementComponent,
    canActivate: [AuthGuard],
    title: "Account Management | EDI",
  },
  {
    path: "regenerateProfile",
    component: RegenerateProfileComponent,
    canActivate: [AuthGuard],
    title: "Regenerate Profile | EDI",
  },
  {
    path: "ecrsUserLookup",
    component: EcrsUserLookupComponent,
    canActivate: [AuthGuard],
    title: "ECRS User Lookup | EDI",
  },
  {
    path: "ecrsContractorLookup",
    component: EcrsContractorLookupComponent,
    canActivate: [AuthGuard],
    title: "ECRS Contractor Lookup | EDI",
  },
  {
    path: "replaceAccountManager",
    component: ReplaceAccountManagerComponent,
    canActivate: [AuthGuard],
    title: "Replace Account Manager | EDI",
  },
  {
    path: "submittersRequiring",
    component: SubmittersRequiringComponent,
    canActivate: [AuthGuard],
    title: "Vetting Submitters | EDI",
  },
  {
    path: "removeInvalid/:id",
    component: RemoveInvalidSubmitterComponent,
    canActivate: [AuthGuard],
  },
  {
    path: "regenProfile/:id",
    component: RegenerateProfileComponent,
    canActivate: [AuthGuard],
  },
  {
    path: "vetSubmitter",
    component: VetSubmitterComponent,
    canActivate: [AuthGuard],
  },
  {
    path: "paperlessEmails/:id",
    component: PaperlessEmailsComponent,
    canActivate: [AuthGuard],
  },
  {
    path: "grantFullFunction/:id",
    component: GrantFullFunctionComponent,
    canActivate: [AuthGuard],
  },
  {
    path: "paperlessParties/:id",
    component: PaperlessPartiesComponent,
    canActivate: [AuthGuard],
  },
  { path: "login", component: LoginComponent, title: "Login | EDI" },
  {
    path: "login/warning",
    component: LoginWarningComponent,
    title: "Login | EDI",
  },
  { path: "version", component: VersionComponent, title: "Version | EDI" },
  {
    path: "sessionException",
    component: SessionExceptionComponent,
    title: "Session Exception | EDI",
  },
  {
    path: "sessionExpired",
    component: SessionExpiredComponent,
    title: "Session Expired | EDI",
  },
  {
    path: "serverError",
    component: ServerErrorComponent,
    title: "Server Error | EDI",
  },
  { path: "notFound", component: NotFoundComponent, title: "Not Found | EDI" },
  { path: "**", redirectTo: "notFound" },
];

@NgModule({
  imports: [
    RouterModule.forRoot(appRoutes, {
      // enableTracing: true,
    }), // Enable tracing is a debug feature
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}

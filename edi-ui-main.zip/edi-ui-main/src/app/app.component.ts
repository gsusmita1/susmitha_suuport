import { Component, HostListener, Inject } from "@angular/core";
import { TimeoutService } from "./services/timeout.service";
import { LoadingSpinnerService } from "./modules/shared-modules/general/loading/loading-spinner.service";
import { AuthService } from "./services/auth.service";
import { ErrorMessagesService } from "./modules/shared-modules/general/error-messages/error-messages.service";
import { ActivatedRoute, NavigationEnd, Router } from "@angular/router";
import { catchError, filter, map, tap } from "rxjs/operators";
import { DOCUMENT } from "@angular/common";
import { environment } from "src/environments/environment";
import { SessionService } from "./services/session.service";
import { ApiService } from "./services/api.service";
import { BehaviorSubject, Observable } from "rxjs";
import { MenuItem } from "primeng/api";
import { RouterService } from "./services/router.service";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"],
})
export class AppComponent {
  // loading: boolean = false;
  error500 = false;
  showIdleWarning = false;
  sessionRoute = false;
  authenticated: boolean = false;
  isAdmin: boolean = false;
  menuItems: MenuItem[];

  constructor(
    private authService: AuthService,
    private session: SessionService,
    private timeoutService: TimeoutService,
    private loadingSpinner: LoadingSpinnerService,
    private errorService: ErrorMessagesService,
    private apiService: ApiService,
    private routerService: RouterService,
    private router: Router,
    private route: ActivatedRoute,
    @Inject(DOCUMENT) private document: any
  ) {
    console.log("ENV: " + environment.name); // Logs false for development environment

    this.timeoutService.setTimeoutSeconds(60 * 14); // call this method if you want to override default 20 minute timeout to 5 mins
    this.authService.authenticated.subscribe((auth) => {
      this.authenticated = auth;
    });
    this.session.current_user.subscribe((user) => {
      if (user) {
        this.isAdmin = user.roleId == 1;
        console.log(this.isAdmin);
      } else {
        this.isAdmin = false;
      }
      this.recreateMenuItems();
    });
    // loadingSpinner
    //   .onLoadingChanged
    //   .subscribe(isLoading => this.loading = isLoading);

    router.events
      .pipe(filter((event) => event instanceof NavigationEnd))
      .subscribe((event: NavigationEnd) => {
        const sessionRoutes = [
          "/",
          "/login",
          "/sessionExpired",
          "/sessionException",
          "/version",
        ];
        let isSessionRoute: boolean = true;
        for (let value of sessionRoutes) {
          if (event["url"].toLowerCase() === value.toLowerCase()) {
            isSessionRoute = false;
            break;
          }
        }
        if (event["url"] && isSessionRoute) {
          this.sessionRoute = true;
          this.timeoutService.startResetTimer();
        } else {
          this.timeoutService.stopTimer();
          this.sessionRoute = false;
        }
      });

    this.timeoutService.idleWarning.subscribe((n) => {
      console.log("Idle warning Triggered next.. " + n.toString());
      this.showIdleWarning = true;
      this.timeoutService.startIdleCountDown();
    });

    this.timeoutService._timeoutExpiredLogOut.subscribe((v) => {
      this.logOut().then(() => {
        this.router.navigate(["sessionExpired"]); // Navigate after logOut finishes
      });
    });

    errorService.http500.subscribe((value) => {
      this.error500 = value;
    });
  }

  @HostListener("mousemove") // this two events should be enough to determine user inactivity
  @HostListener("keypress")
  resetIdleTime() {
    if (!this.showIdleWarning && this.sessionRoute) {
      this.timeoutService.startResetTimer();
    }
  }

  ngOnInit() {
    this.recreateMenuItems();
  }

  recreateMenuItems() {
    this.menuItems = [
      {
        label: "User Access Lookup",
        command: (event) => {
          this.routerService.returnToUserAccess$.next(false);
        },
        routerLink: ["/dashboard"],
        routerLinkActiveOptions: { exact: true },
      },
      {
        label: "Account Lookup",
        routerLink: ["/accountManagement"],
        routerLinkActiveOptions: { exact: true },
      },
      {
        label: "Replace Account Manager",
        routerLink: ["/replaceAccountManager"],
        routerLinkActiveOptions: { exact: true },
      },
      {
        label: "Change Authorized Representative",
        routerLink: ["/accountAuthorized"],
        expanded: true,
        routerLinkActiveOptions: { exact: true },
      },
      {
        label: "Vetting Submitters",
        routerLink: ["/submittersRequiring"],
        routerLinkActiveOptions: { exact: true },
      },

      {
        label: "ECRS User Lookup",
        routerLink: ["/ecrsUserLookup"],
        routerLinkActiveOptions: { exact: true },
      },
      {
        label: "ECRS Contractor Lookup",
        routerLink: ["/ecrsContractorLookup"],
        routerLinkActiveOptions: { exact: true },
      },
      {
        label: "Bulletin Board",
        routerLink: ["/bulletinBoard"],
        routerLinkActiveOptions: { exact: true },
        visible: this.isAdmin,
      },
      {
        label: "Prototype Links",
        url: "",
        items: [
          {
            label: "CRCP",
            command: (click) => {
              window.open(
                "https://www.cob.cms.hhs.gov/EDI/Prototype/GHPRPPrototype/index.html",
                "_blank"
              );
            },
          },
          {
            label: "ECRS",
            command: (click) => {
              window.open(
                "https://www.cob.cms.hhs.gov/EDI/ECRSPrototype/HomePage.htm",
                "_blank"
              );
            },
          },
          {
            label: "MRA/Section 111",
            command: (click) => {
              window.open(
                "https://www.cob.cms.hhs.gov/EDI/MRAPrototype/default.htm",
                "_blank"
              );
            },
          },
          {
            label: "MSPRP",
            command: (click) => {
              window.open(
                "https://www.cob.cms.hhs.gov/EDI/Prototype/MSPRPPrototype/loginwarning.htm",
                "_blank"
              );
            },
          },
          {
            label: "WCMSAP ",
            command: (click) => {
              window.open(
                "https://www.cob.cms.hhs.gov/EDI/WCSAPrototype/default.htm",
                "_blank"
              );
            },
          },
        ],
      },
    ];
  }

  stayLoggedIn() {
    this.timeoutService.startResetTimer();
    this.showIdleWarning = false;
    this.refreshToken(); // get a new token
  }

  logOutPressed() {
    this.logOut();
    this.document.location.href = environment.url;
  }

  private async logOut() {
    console.log("APP LOGOUT TRIGGERED");
    // do session.logout always before authService.logout
    await this.session.logout(this.authService.validated).finally(() => {
      this.authService.logout();
      this.timeoutService.stopTimer();
      this.showIdleWarning = false;
    });
  }

  onActivate(event: Event) {
    window.scrollTo(0, 0); // This will reset the scroll for every page to the top
  }

  @HostListener("window:beforeunload", ["$event"])
  async beforeUnloadHandler(event) {
    console.log("App unloading");
    await this.session.logout(this.authService.validated);
    this.authService.logout();
  }

  refreshToken(): Observable<string> {
    this.authService.token_expired = true;
    return this.apiService.doRefreshToken().pipe(
      map(
        (data) => {
          this.authService.setToken(data.result.toString());
          this.authService.token_expired = false;
          return data.result.toString();
        },
        catchError((e) => {
          console.log(e);
          return "";
        })
      )
    );
  }

  navigateTo(route, state: boolean = null) {
    this.routerService.navigateTo(route, state);
  }
}

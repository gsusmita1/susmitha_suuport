import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import { Observable, of } from "rxjs";
import { EdiResponse } from "../model/edi-respose.model";
import { API_BASE } from "./constants";

export const BULLETIN_BOARD = `${API_BASE}/bulletinboards`;

@Injectable()
export class BulletinBoardService {
  constructor(private httpClient: HttpClient) {}

  getLatestMessages(): Observable<EdiResponse> {
    return this.httpClient.get<EdiResponse>(BULLETIN_BOARD);
  }

  submitBulletinBoardMessages(applications: string[], message: string) {
    const data = [];
    applications.forEach((app) => {
      data.push({ application: app, message: message });
    });
    return this.httpClient.post(BULLETIN_BOARD, data);
  }
}

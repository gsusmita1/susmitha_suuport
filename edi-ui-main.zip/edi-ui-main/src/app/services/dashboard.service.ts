import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable, of } from "rxjs";
import { EdiResponse } from "../model/edi-respose.model";
import { API_BASE } from "../services/constants";

export const USER_ACCESS = `${API_BASE}/person`;

@Injectable()
export class DashboardService {
  private currentUserAccount;

  constructor(private http: HttpClient) {}

  setUserAccessAccount(user) {
    this.currentUserAccount = user;
  }

  getUserAccessAccount() {
    return this.currentUserAccount;
  }

  userLookup(criteria, isEmail): Observable<EdiResponse> {
    let params = new HttpParams();
    params = isEmail
      ? params.set("email", criteria)
      : params.set("loginid", criteria);
    return this.http.get<EdiResponse>(USER_ACCESS, {
      params,
    });
  }

  sendPersonAction(personInfo): Observable<EdiResponse> {
    return this.http.post<EdiResponse>(USER_ACCESS, personInfo);
  }
}

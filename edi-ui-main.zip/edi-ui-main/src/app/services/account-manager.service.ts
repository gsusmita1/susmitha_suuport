import { Injectable } from "@angular/core";
import { HttpClient, HttpParams } from "@angular/common/http";
import { Observable } from "rxjs";
import { EdiResponse } from "../model/edi-respose.model";
import { API_BASE } from "./constants";

export const AM_URL = `${API_BASE}/am`;
export const AM_SAVE_URL = `${API_BASE}/am/save`;

@Injectable()
export class AccountManagerService {
  constructor(private httpClient: HttpClient) {}

  getCurrentAccountManagerData(
    appType: string,
    searchCriteria: any,
    isEmail: boolean
  ): Observable<EdiResponse> {
    let params = new HttpParams();
    params = params.set("appType", appType);
    if (appType === "MRA") {
      params = params.set("rreId", searchCriteria);
    } else {
      params = isEmail
        ? params.set("email", searchCriteria)
        : params.set("accountId", searchCriteria);
    }
    return this.httpClient.get<EdiResponse>(AM_URL, {
      params,
    });
  }

  replaceAccountManagerEmail(
    appType: string,
    email: string
  ): Observable<EdiResponse> {
    let params = new HttpParams();
    params = params.set("appType", appType);
    params = params.set("email", email);

    return this.httpClient.get<EdiResponse>(AM_URL + "/replace", {
      params,
    });
  }

  replaceAccountManager(appType: string, data: any): Observable<EdiResponse> {
    let params = new HttpParams();
    params = params.set("appType", appType);
    return this.httpClient.post<EdiResponse>(AM_SAVE_URL, data, {
      params,
    });
  }
}

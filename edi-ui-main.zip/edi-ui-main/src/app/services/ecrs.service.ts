import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { EdiResponse } from "../model/edi-respose.model";
import { API_BASE } from "./constants";

export const ECRS_URL = `${API_BASE}/ecrs`;

@Injectable()
export class EcrsService {
  constructor(private httpClient: HttpClient) {}

  getContractorData( contractorNo: string): Observable<EdiResponse> {
    let dataUrl = ECRS_URL + "/contractorData?contractorNo=" + contractorNo;
    return this.httpClient.get<EdiResponse>(dataUrl);
  }

  lookupContractorsByUserId( userId: string): Observable<EdiResponse> {
    let dataUrl = ECRS_URL + "/uploadContractorList?userId=" + userId;
    return this.httpClient.get<EdiResponse>(dataUrl);
  }

  addContractor( userId: string, contractorNo: string): Observable<EdiResponse> {
    let addContractorUrl = ECRS_URL.concat("/contractor/add");
    let req = {
      "userId" : userId,
      "contractorNo" : contractorNo
    };
    return this.httpClient.post<EdiResponse>(addContractorUrl, req);
  }

  revokeContractors( userId: string, contractors: any[]): Observable<EdiResponse> {
    let revokeContractorUrl = ECRS_URL.concat("/contractor/revoke");
    let req = {
      "userId" : userId,
      "contractors": contractors
    };
   return this.httpClient.post<EdiResponse>(revokeContractorUrl, req);
  }

}

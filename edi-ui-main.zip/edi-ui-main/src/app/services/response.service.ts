import { Injectable } from "@angular/core";
import { EdiResponse } from "../model/edi-respose.model";
import systemErrors from "./system-errors";
import { Message } from "primeng/api";

@Injectable({
  providedIn: "root",
})
export class ResponseService {
  constructor() {}

  /**
   * Technically remove an error from the response
   * @param response Response object from backend
   * @param fieldName Error to ignore or remove
   */
  ignoreErrorFromResponse(
    response: EdiResponse,
    fieldName: string
  ): EdiResponse {
    if (response.errors) {
      const length = response.errors.length;
      let position = 0;
      for (let i = 0; i < length; i++) {
        let error = response.errors[position];
        if (error.field?.includes(fieldName)) {
          response.errors.splice(position, 1);
        } else {
          position++;
        }
      }
    }
    return response;
  }

  validateResponse(data: EdiResponse): any[] {
    let errors = [];
    if (!data) {
      errors.push(this.getErrorMessage("error.badResponse"));
    } else if( data.status != 200 ) {
      // error response
      console.log(data);
      if (data.errors) {
        errors.push(...this.formatErrors(data.errors));
      } else {
        if (data.result === null) {
          // Will capture null and undefined
          errors.push(this.getErrorMessage("error.badResponse"));
        }
      }
    }
    return errors;
  }

  createErrorMessage(result: any): Message {
    return { detail: result };
  }

  findError(response: EdiResponse, fieldName: string): boolean {
    if (response.errors) {
      for (let error of response.errors) {
        if (error.field?.includes(fieldName)) {
          return true;
        }
      }
    }
    return false;
  }

  contains(errors: Message[], value: string): boolean {
    errors.forEach((error) => {
      if (error?.detail) {
        if (error.detail.includes(value)) {
          return true;
        }
      }
      if( error?.key) {
        if (error.key.includes(value)) {
          return true;
        }

      }
    });
    return false;
  }

  handleError(errorJson): Message[] {
    let messages = [];
    if (errorJson.name) {
      // If it is a default http error
      messages.push({ detail: errorJson.error.error });
    } else {
      if (errorJson.errors) {
        errorJson.errors.forEach((value) => {
          messages.push({ detail: value.message ?? value, summary: value.field });
        });
      }
    }
    return messages;
  }


  formatErrors(errors: string[]): Message[] {
    let messages = [];
    errors.forEach((value) => {
      messages.push(this.getErrorMessage(value));
    });
    return messages;
  }

  getErrorMessage(key: string): any {
    if( systemErrors[key] ) {
      return { detail: systemErrors[key], key: key };
    }
    return { detail: key, key: "MESSAGE"}
  }

  getWarnings(data: EdiResponse): any[] {
    const warnings = [];
    if (data.errors) {
      for (let item of data.errors) {
        if (item.field?.includes("warning")) {
          warnings.push({ detail: item.message, summary: item.field });
        }
      }
    }
    return warnings;
  }
}

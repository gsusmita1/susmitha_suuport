import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ApiService } from './api.service';
import { State } from '../model/state.interface';

@Injectable(
  { providedIn: 'root' }
)
export class DropDownService {

  constructor(private apiService: ApiService) {
  }

  findKeyInMap(map: any[], key: string): any {
    return map.find(x => +x.id === +key);
  }

  findValueInMap(map: any[], value: string): any {
    return map.find(x => x.value === value);
  }

  getValueFromArrayById(array: any[], id: number) {
    const item = array.find(x => x.id === id);
    return (item ? item.value : 'NA');
  }

  getStatesKeyValues(array: any[]) {
    let tempArray = [];
    for (let item of array) {
      if (item.stateId !== 1) { // 1 = Not Defined
        tempArray.push({ id: item.stateId, value: item.stateName });
      }
    }
    return tempArray;
  }

  getStateList(): State[]{
    return [
      {name: 'Select', code: ''},
      {name: 'Alabama', code: 'AL'},
      {name: 'Alaska', code: 'AK'},
      {name: 'Arizona', code: 'AZ'},
      {name: 'Arkansas', code: 'AR'},
      {name: 'California', code: 'CA'},
      {name: 'Colorado', code: 'CO'},
      {name: 'Connecticut', code: 'CT'},
      {name: 'Delaware', code: 'DE'},
      {name: 'District Of Columbia', code: 'DC'},
      {name: 'Florida', code: 'FL'},
      {name: 'Georgia', code: 'GA'},
      {name: 'Hawaii', code: 'HI'},
      {name: 'Idaho', code: 'ID'},
      {name: 'Illinois', code: 'IL'},
      {name: 'Indiana', code: 'IN'},
      {name: 'Iowa', code: 'IA'},
      {name: 'Kansas', code: 'KS'},
      {name: 'Kentucky', code: 'KY'},
      {name: 'Louisiana', code: 'LA'},
      {name: 'Maine', code: 'ME'},
      {name: 'Maryland', code: 'MD'},
      {name: 'Massachusetts', code: 'MA'},
      {name: 'Michigan', code: 'MI'},
      {name: 'Minnesota', code: 'MN'},
      {name: 'Mississippi', code: 'MS'},
      {name: 'Missouri', code: 'MO'},
      {name: 'Montana', code: 'MT'},
      {name: 'Nebraska', code: 'NE'},
      {name: 'Nevada', code: 'NV'},
      {name: 'New Hampshire', code: 'NH'},
      {name: 'New Jersey', code: 'NJ'},
      {name: 'New Mexico', code: 'NM'},
      {name: 'New York', code: 'NY'},
      {name: 'North Carolina', code: 'NC'},
      {name: 'North Dakota', code: 'ND'},
      {name: 'Ohio', code: 'OH'},
      {name: 'Oklahoma', code: 'OK'},
      {name: 'Oregon', code: 'OR'},
      {name: 'Pennsylvania', code: 'PA'},
      {name: 'Rhode Island', code: 'RI'},
      {name: 'South Carolina', code: 'SC'},
      {name: 'South Dakota', code: 'SD'},
      {name: 'Tennessee', code: 'TN'},
      {name: 'Texas', code: 'TX'},
      {name: 'Utah', code: 'UT'},
      {name: 'Vermont', code: 'VT'},
      {name: 'Virginia', code: 'VA'},
      {name: 'Washington', code: 'WA'},
      {name: 'West Virginia', code: 'WV'},
      {name: 'Wisconsin', code: 'WI'},
      {name: 'Wyoming', code: 'WY'},
    ];
  }

}

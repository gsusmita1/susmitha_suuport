import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { API_BASE } from "./constants";
import { EdiResponse } from "../model/edi-respose.model";
import { BehaviorSubject, Observable } from "rxjs";

export const ACCOUNT_REP = `${API_BASE}/ar`;
export const ACCOUNT_INFO = `${API_BASE}/account`;
export const DOWNLOAD_EMAIL_IMAGE = `${API_BASE}/account/email`;

@Injectable()
export class AccountService {
  constructor(private http: HttpClient) {}

  activeAccountInfo: BehaviorSubject<any> = new BehaviorSubject<any>({});
  activeAccountType: BehaviorSubject<string> = new BehaviorSubject<string>("");

  accountRepLookup(value, prop): Observable<EdiResponse> {
    let params = new HttpParams();
    params = params.set(prop, value);

    return this.http.get<EdiResponse>(ACCOUNT_REP, {
      params,
    });
  }

  accountInfoLookup(value, prop, appType): Observable<EdiResponse> {
    let params = new HttpParams();
    params = params.set("appType", appType);
    params = params.set(prop, value);
    return this.http.get<EdiResponse>(ACCOUNT_INFO, {
      params,
    });
  }

  sendAccountAction(accountInfo, appType): Observable<EdiResponse> {
    let params = new HttpParams();
    params = params.set("appType", appType);
    return this.http.post<EdiResponse>(ACCOUNT_INFO, accountInfo, { params });
  }

  getPaperlessEmails(
    accountInfo,
    appType,
    accountId,
    fromDate,
    thruDate
  ): Observable<EdiResponse> {
    let params = new HttpParams();
    params = params.set("accountId", accountId);
    params = params.set("appType", appType);
    params = params.set("emailFrom", fromDate);
    params = params.set("emailTo", thruDate);
    return this.http.post<EdiResponse>(ACCOUNT_INFO, accountInfo, {
      params,
    });
  }

  downloadEmailImage(appType: any, emailImageId: any) {
    let params = new HttpParams();
    params = params.set("appType", appType);
    params = params.set("imageId", emailImageId);

    return this.http.get<EdiResponse>(DOWNLOAD_EMAIL_IMAGE, {
      params,
    });
  }
}

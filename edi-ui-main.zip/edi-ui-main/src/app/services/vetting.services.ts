import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { API_BASE } from "../services/constants";

export const VETTING_URL = `${API_BASE}/account/vetted`;

@Injectable()
export class VettingService {
  constructor(private http: HttpClient) {}

  getVettingDetails() {
    return this.http.get(VETTING_URL);
  }
}

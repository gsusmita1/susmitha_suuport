export class MirRrePrsn {
  public rrePrsnId:number|null = null;
  public roleId:number|null = null;
  public prsnId:number|null = null;
  public rptrId:number|null = null;
  public rptrName: string|null = '';
  public emailScrtyTokenId?: string|null= '';
  public prsnlScrtyId?: string|null = '';
  public pndngRplcSw?: string|null = '';
  public recAddTs: any = undefined;
  public recAddUserName: string|null = '';
  public recUpdtTs: any = undefined;
  public recUpdtUserName: string|null = '';
  public rreStusId:number|null = null;
  public pndngPrmteSw?: string|null = '';
}

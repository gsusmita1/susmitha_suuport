export class EdiResponse {
    status: number;
    errors: any[];
    result: any;
    timestamp: string;
  }
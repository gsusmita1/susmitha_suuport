export class MirRrePrsn {
  public rrePrsnId = 0;
  public roleId = 0;

  /*
  @JsonProperty('PRSN_ID', Number)
  public prsnId = 0;
  
  @JsonProperty('RPTR_ID', Number)
  public rptrId:number = 0;

  @JsonProperty('EMAIL_SCRTY_TOKEN_ID', String)
  public emailScrtyTokenId = '';

  @JsonProperty('PRSNL_SCRTY_ID', String)
  public prsnlScrtyId = '';

  @JsonProperty('PNDNG_RPLC_SW', String)
  public pndngRplcSw = '';

  @JsonProperty('REC_ADD_TS', Any)
  public recAddTs: any = undefined;

  @JsonProperty('REC_ADD_USER_NAME', String)
  public recAddUserName = '';

  @JsonProperty('REC_UPDT_TS', Any)
  public recUpdtTs: any = undefined;

  @JsonProperty('REC_UPDT_USER_NAME', String)
  public recUpdtUserName = '';

  @JsonProperty('RRE_STUS_ID', Number)
  public rreStusId = 0;

  @JsonProperty('PNDNG_PRMTE_SW', String)
  public pndngPrmteSw = '';
  */
}
